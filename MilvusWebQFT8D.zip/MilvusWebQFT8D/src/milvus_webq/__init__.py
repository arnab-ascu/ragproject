"""Modular offline RAG pipeline backed by Docker Milvus."""

__all__ = ["__version__"]

__version__ = "0.1.0"
