"""In-memory, interpretable telemetry for the Day-2 RAPID scheduler."""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from typing import Any

from .config import RuntimeConfig


@dataclass
class EWMA:
    value: float
    samples: int = 0

    def update(self, sample: float, alpha: float) -> None:
        self.value = alpha * sample + (1 - alpha) * self.value
        self.samples += 1


@dataclass
class ReplicaTelemetry:
    active_requests: int = 0
    completed_requests: int = 0
    stages: dict[str, dict[str, EWMA]] = field(default_factory=dict)
    model_stages: dict[str, dict[str, EWMA]] = field(default_factory=dict)


def profile_key(profile: dict[str, Any]) -> str:
    """Only cost-changing fields participate in a telemetry profile."""
    keys = (
        "model", "execution_mode", "include_hyde", "use_reranker",
        "bm25_candidates", "dense_top_k", "rerank_top_k", "llm_num_predict",
        "hyde_num_predict",
    )
    return "|".join(f"{key}={profile.get(key)}" for key in keys)


class RapidTelemetry:
    def __init__(self, config: RuntimeConfig):
        self.config = config
        self.replicas = {name: ReplicaTelemetry() for name in config.scheduler_backends}
        self._round_robin_index = 0
        self._lock = threading.Lock()

    def _default(self, stage: str) -> float:
        return {
            "hyde": self.config.rapid_default_hyde_ms,
            "retrieval": self.config.rapid_default_retrieval_ms,
            "generation": self.config.rapid_default_generation_ms,
        }[stage]

    def _estimate_stage(self, replica: ReplicaTelemetry, stage: str, key: str, model: str | None = None) -> EWMA:
        if key in replica.stages.get(stage, {}):
            return replica.stages[stage][key]
        if model and model in replica.model_stages and stage in replica.model_stages[model]:
            return replica.model_stages[model][stage]
        return EWMA(self._default(stage), 0)

    def _predicted_service_ms(self, replica: ReplicaTelemetry, profile: dict[str, Any], key: str) -> tuple[float, int]:
        stages = ["retrieval"]
        if profile.get("include_hyde"):
            stages.insert(0, "hyde")
        if profile.get("execution_mode") == "full_rag":
            stages.append("generation")
        model = str(profile.get("model") or "default")
        estimates = [self._estimate_stage(replica, stage, key, model=model) for stage in stages]
        return sum(item.value for item in estimates), min((item.samples for item in estimates), default=0)

    def choose(self, profile: dict[str, Any], mode: str | None = None) -> dict[str, Any]:
        """Reserve and return a deterministic routing decision.

        RAPID blends cost with least-connections during cold start. The reserve is
        released by ``record_completion`` even when the backend request fails.
        """
        policy = mode or self.config.scheduler_mode
        key = profile_key(profile)
        with self._lock:
            names = sorted(self.replicas)
            if policy == "round_robin":
                selected = names[self._round_robin_index % len(names)]
                self._round_robin_index += 1
                scores = {name: {"final_ms": float(index)} for index, name in enumerate(names)}
                reason = "round-robin baseline"
            else:
                rows: dict[str, dict[str, float]] = {}
                for name in names:
                    replica = self.replicas[name]
                    service_ms, samples = self._predicted_service_ms(replica, profile, key)
                    queue_ms = replica.active_requests * service_ms
                    predicted_ms = queue_ms + service_ms
                    confidence = min(samples / max(self.config.rapid_min_samples, 1), 1.0)
                    beta = self.config.rapid_uncertainty_floor + (1 - self.config.rapid_uncertainty_floor) * confidence
                    least_conn_ms = (replica.active_requests + 1) * service_ms
                    final_ms = least_conn_ms if policy == "least_conn" else beta * predicted_ms + (1 - beta) * least_conn_ms
                    rows[name] = {
                        "active_requests": float(replica.active_requests),
                        "service_ms": service_ms,
                        "queue_ms": queue_ms,
                        "predicted_ms": predicted_ms,
                        "samples": float(samples),
                        "confidence": confidence,
                        "blend_beta": beta,
                        "least_conn_ms": least_conn_ms,
                        "final_ms": final_ms,
                    }
                selected = min(names, key=lambda name: (rows[name]["final_ms"], name))
                scores = rows
                reason = "least-connections baseline" if policy == "least_conn" else "lowest confidence-blended predicted completion time"
            self.replicas[selected].active_requests += 1
            return {
                "mode": policy,
                "selected_backend": selected,
                "profile_key": key,
                "reason": reason,
                "candidates": scores,
            }

    def record_completion(
        self,
        backend: str,
        profile: dict[str, Any],
        timings_ms: dict[str, Any] | None,
    ) -> None:
        key = profile_key(profile)
        model = str(profile.get("model") or "default")
        with self._lock:
            replica = self.replicas[backend]
            replica.active_requests = max(0, replica.active_requests - 1)
            replica.completed_requests += 1
            for stage, raw_ms in (timings_ms or {}).items():
                if stage not in {"hyde", "retrieval", "generation"} or raw_ms is None:
                    continue
                stage_profiles = replica.stages.setdefault(stage, {})
                estimate = stage_profiles.setdefault(key, EWMA(float(raw_ms), 0))
                estimate.update(float(raw_ms), self.config.rapid_alpha)
                model_profiles = replica.model_stages.setdefault(model, {})
                model_estimate = model_profiles.setdefault(stage, EWMA(float(raw_ms), 0))
                model_estimate.update(float(raw_ms), self.config.rapid_alpha)

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            return {
                name: {
                    "active_requests": replica.active_requests,
                    "completed_requests": replica.completed_requests,
                    "stages": {
                        stage: {key: {"ewma_ms": item.value, "samples": item.samples} for key, item in profiles.items()}
                        for stage, profiles in replica.stages.items()
                    },
                    "model_profiles": {
                        model: {stage: {"ewma_ms": item.value, "samples": item.samples} for stage, item in stages.items()}
                        for model, stages in replica.model_stages.items()
                    },
                }
                for name, replica in self.replicas.items()
            }
