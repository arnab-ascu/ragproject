"""Drive independent requests through Nginx and save Day-1 routing evidence.

Unlike ``scripts/stress_api.py``, this client never calls RAGService directly.
Every request is POSTed to the load-balancer URL, so trace.route.external_backend
identifies the replica that Nginx actually selected.
"""

from __future__ import annotations

import argparse
import csv
import json
import random
import statistics
import sys
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_QUERIES = [
    "Impact of ambulance dispatch policies",
    "How does sparse attention reduce transformer complexity?",
    "What is the role of retrieval augmentation in language models?",
    "How do document ranking methods affect scientific search?",
]
WORKLOADS: dict[str, dict[str, Any]] = {
    "S": {"execution_mode": "retrieval_only", "include_hyde": False, "use_reranker": False},
    "M": {"execution_mode": "retrieval_only", "include_hyde": False, "use_reranker": True},
    "L": {"execution_mode": "retrieval_only", "include_hyde": True, "use_reranker": True},
    "XL": {"execution_mode": "full_rag", "include_hyde": True, "use_reranker": True},
}
LOG_FIELDS = [
    "request_id", "workload_class", "send_time", "end_time", "latency_ms", "status",
    "error", "external_backend", "internal_worker", "model", "execution_mode",
    "hyde_used", "use_reranker", "bm25_candidates", "dense_top_k", "rerank_top_k", "llm_num_predict",
    "hyde_num_predict", "hyde_ms", "retrieval_ms", "generation_ms", "total_ms",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="End-to-end Nginx workload generator for RAPID-RAG.")
    parser.add_argument("--url", default="http://localhost:8080/query", help="Nginx /query endpoint")
    parser.add_argument("--concurrency", type=int, default=2)
    parser.add_argument("--requests", type=int, default=20)
    parser.add_argument("--queries-file", type=Path, help="One query per line")
    parser.add_argument("--workload", choices=["S", "M", "L", "XL", "MIX"], default="S")
    parser.add_argument("--scheduler-mode", choices=["round_robin", "least_conn", "rapid"], help="Ingress routing policy")
    parser.add_argument("--model", help="Requested Ollama model; omitted uses the server default")
    parser.add_argument("--execution-mode", choices=["retrieval_only", "full_rag"], help="Override workload mode")
    parser.add_argument("--hyde", action=argparse.BooleanOptionalAction, default=None, help="Override workload HyDE")
    parser.add_argument("--llm-num-predict", type=int, default=64)
    parser.add_argument("--hyde-num-predict", type=int, default=32)
    parser.add_argument("--seed", type=int, default=20260916)
    parser.add_argument("--timeout", type=float, default=600.0)
    parser.add_argument("--output-dir", type=Path, help="Directory for CSV, JSONL, and run summary")
    return parser.parse_args()


def read_queries(path: Path | None) -> list[str]:
    if not path:
        return DEFAULT_QUERIES
    queries = [line.strip() for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if not queries:
        raise ValueError("queries file contains no non-empty lines")
    return queries


def request_profile(args: argparse.Namespace, rng: random.Random) -> tuple[str, dict[str, Any]]:
    workload = rng.choice(list(WORKLOADS)) if args.workload == "MIX" else args.workload
    profile = dict(WORKLOADS[workload])
    if args.execution_mode:
        profile["execution_mode"] = args.execution_mode
    if args.hyde is not None:
        profile["include_hyde"] = args.hyde
    profile.update(
        include_trace=True,
        llm_num_predict=args.llm_num_predict,
        hyde_num_predict=args.hyde_num_predict,
    )
    if args.model:
        profile["llm_model"] = args.model
    if args.scheduler_mode:
        profile["scheduler_mode"] = args.scheduler_mode
    return workload, profile


def send_request(url: str, payload: dict[str, Any], timeout: float) -> tuple[int, dict[str, Any], str | None]:
    request = Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urlopen(request, timeout=timeout) as response:
            return response.status, json.loads(response.read().decode("utf-8")), None
    except HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        return exc.code, {}, body
    except (URLError, TimeoutError, json.JSONDecodeError) as exc:
        return 0, {}, str(exc)


def flatten_record(record: dict[str, Any], payload: dict[str, Any], response: dict[str, Any]) -> dict[str, Any]:
    trace = response.get("trace") or {}
    route = trace.get("route") or {}
    profile = trace.get("request_profile") or {}
    timings = trace.get("timings_ms") or {}
    record.update(
        external_backend=route.get("external_backend"),
        internal_worker=route.get("internal_worker"),
        model=profile.get("model", payload.get("llm_model")),
        execution_mode=trace.get("execution_mode", payload["execution_mode"]),
        hyde_used=trace.get("hyde_used", payload["include_hyde"]),
        use_reranker=profile.get("use_reranker", payload.get("use_reranker")),
        bm25_candidates=profile.get("bm25_candidates"),
        dense_top_k=profile.get("dense_top_k"),
        rerank_top_k=profile.get("rerank_top_k"),
        llm_num_predict=profile.get("llm_num_predict", payload["llm_num_predict"]),
        hyde_num_predict=profile.get("hyde_num_predict", payload["hyde_num_predict"]),
        hyde_ms=timings.get("hyde"),
        retrieval_ms=timings.get("retrieval"),
        generation_ms=timings.get("generation"),
        total_ms=trace.get("total_ms"),
    )
    return record


def main() -> None:
    args = parse_args()
    if args.concurrency < 1 or args.requests < 1:
        raise SystemExit("--concurrency and --requests must be positive")
    rng = random.Random(args.seed)
    queries = read_queries(args.queries_file)
    output_dir = args.output_dir or ROOT / "results" / "runs" / datetime.now().strftime("%Y%m%dT%H%M%S")
    output_dir.mkdir(parents=True, exist_ok=True)
    rng_lock = threading.Lock()

    def run_one(index: int) -> dict[str, Any]:
        with rng_lock:
            workload, payload = request_profile(args, rng)
        payload["query"] = queries[index % len(queries)]
        request_id = str(uuid.uuid4())
        sent = datetime.now(timezone.utc)
        started = time.perf_counter()
        status, response, error = send_request(args.url, payload, args.timeout)
        ended = datetime.now(timezone.utc)
        record: dict[str, Any] = {
            "request_id": request_id,
            "workload_class": workload,
            "send_time": sent.isoformat(),
            "end_time": ended.isoformat(),
            "latency_ms": round((time.perf_counter() - started) * 1000, 3),
            "status": status,
            "error": error,
        }
        record["response"] = response
        return flatten_record(record, payload, response)

    wall_started = time.perf_counter()
    with ThreadPoolExecutor(max_workers=args.concurrency) as executor:
        records = [future.result() for future in as_completed([executor.submit(run_one, i) for i in range(args.requests)])]
    wall_seconds = time.perf_counter() - wall_started
    records.sort(key=lambda item: item["send_time"])
    successful = [row for row in records if 200 <= int(row["status"] or 0) < 300]
    latencies = sorted(float(row["latency_ms"]) for row in successful)
    percentile = lambda p: latencies[round((len(latencies) - 1) * p)] if latencies else None
    summary = {
        "url": args.url,
        "scheduler_mode": args.scheduler_mode,
        "concurrency": args.concurrency,
        "requests": args.requests,
        "workload": args.workload,
        "seed": args.seed,
        "wall_seconds": wall_seconds,
        "successful_requests": len(successful),
        "errors": len(records) - len(successful),
        "qps": len(successful) / wall_seconds if wall_seconds else 0,
        "mean_ms": statistics.mean(latencies) if latencies else None,
        "p50_ms": percentile(0.50),
        "p95_ms": percentile(0.95),
        "p99_ms": percentile(0.99),
        "backend_counts": {backend: sum(row["external_backend"] == backend for row in successful) for backend in sorted({row["external_backend"] for row in successful}, key=str)},
    }
    (output_dir / "requests.jsonl").write_text("".join(json.dumps(row) + "\n" for row in records), encoding="utf-8")
    with (output_dir / "requests.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=LOG_FIELDS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(records)
    (output_dir / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"output_dir": str(output_dir), **summary}, indent=2))


if __name__ == "__main__":
    main()
