from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from milvus_webq.config import load_config
from milvus_webq.service import RAGService


def main() -> None:
    parser = argparse.ArgumentParser(description="Create/index the limited Milvus collection.")
    parser.add_argument("--config", default=None)
    parser.add_argument("--rebuild", action="store_true")
    args = parser.parse_args()

    service = RAGService(load_config(args.config))
    stats = service.ensure_indexed(rebuild=args.rebuild)
    print("Collection:", service.store.name)
    print("Stats:", stats)


if __name__ == "__main__":
    main()
