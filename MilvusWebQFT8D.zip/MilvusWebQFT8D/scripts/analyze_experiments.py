#!/usr/bin/env python3
"""
RAPID-RAG Day 7: Statistical Analysis & Research Paper Package Generator.

Analyzes raw request logs and matrix summaries across B0 (Round-Robin), B1 (Least-Conn),
B2 (RAPID v0), and B3 (RAPID + Adaptive Budgets).

Computes:
  - Latency percentiles (P50, P95, P99)
  - Stage timings (HyDE, Retrieval, Generation)
  - QPS & Throughput speedup ratios
  - SLO Compliance rates
  - Backend load balance & Routing Regret
  - Adaptive state breakdown (NORMAL, BUSY, SATURATED)

Outputs:
  - results/paper_package/table_latency_slo_comparison.md
  - results/paper_package/table_latency_slo_comparison.tex
  - results/paper_package/statistical_summary.json
"""

import csv
import json
import math
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Tuple

PROJECT_ROOT = Path(__file__).resolve().parents[1]
RUNS_DIR = PROJECT_ROOT / "results" / "runs"
OUTPUT_DIR = PROJECT_ROOT / "results" / "paper_package"


def percentile(data: List[float], pct: float) -> float:
    if not data:
        return 0.0
    sorted_data = sorted(data)
    k = (len(sorted_data) - 1) * (pct / 100.0)
    f = math.floor(k)
    c = math.ceil(k)
    if f == c:
        return sorted_data[int(k)]
    d0 = sorted_data[int(f)] * (c - k)
    d1 = sorted_data[int(c)] * (k - f)
    return round(d0 + d1, 2)


def load_all_runs(runs_dir: Path) -> List[Dict[str, Any]]:
    runs: List[Dict[str, Any]] = []
    if not runs_dir.exists():
        return runs

    for run_path in sorted(runs_dir.iterdir()):
        if not run_path.is_dir():
            continue
        summary_file = run_path / "summary.json"
        requests_file = run_path / "requests.csv"

        if summary_file.exists():
            try:
                summary = json.loads(summary_file.read_text(encoding="utf-8"))
                summary["run_dir"] = str(run_path)
                
                # Load request-level details if available
                if requests_file.exists():
                    req_list = []
                    with requests_file.open(encoding="utf-8") as f:
                        reader = csv.DictReader(f)
                        for row in reader:
                            req_list.append({
                                "total_ms": float(row.get("total_ms", 0.0)),
                                "hyde_ms": float(row.get("hyde_ms", 0.0)),
                                "retrieval_ms": float(row.get("retrieval_ms", 0.0)),
                                "generation_ms": float(row.get("generation_ms", 0.0)),
                                "status_code": int(row.get("status_code", 500)),
                                "assigned_backend": row.get("assigned_backend", "unknown"),
                                "adaptive_state": row.get("adaptive_state", "NORMAL"),
                                "slo_violation": row.get("slo_violation", "False").lower() == "true",
                            })
                    summary["raw_requests"] = req_list
                runs.append(summary)
            except Exception as exc:
                print(f"[WARN] Failed to load {summary_file}: {exc}")
    return runs


def generate_paper_package(runs: List[Dict[str, Any]], output_dir: Path) -> Dict[str, Any]:
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Group runs by Policy and Workload
    cell_map: Dict[Tuple[str, str], Dict[str, Any]] = {}
    for r in runs:
        if "policy" not in r or "workload" not in r:
            continue
        key = (r["policy"], r["workload"])
        # Keep latest run per cell
        if key not in cell_map or r.get("timestamp", "") > cell_map[key].get("timestamp", ""):
            cell_map[key] = r

    policies = ["B0", "B1", "B2", "B3"]
    workloads = ["S", "M", "L", "XL", "MIX"]
    
    # Calculate relative speedups of B3 over B0 and B1
    analysis_stats = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "total_runs_analyzed": len(cell_map),
        "cells": {},
        "summary_metrics": {},
    }
    
    for (pol, wk), cell in cell_map.items():
        cell_key = f"{pol}_{wk}"
        analysis_stats["cells"][cell_key] = {
            "policy": pol,
            "policy_name": cell.get("policy_name", pol),
            "workload": wk,
            "qps": cell.get("qps", 0.0),
            "latency_p50_ms": cell.get("latency_p50_ms", 0.0),
            "latency_p95_ms": cell.get("latency_p95_ms", 0.0),
            "latency_p99_ms": cell.get("latency_p99_ms", 0.0),
            "slo_compliance_pct": cell.get("slo_compliance_pct", 0.0),
            "imbalance_ratio": cell.get("imbalance_ratio", 1.0),
            "adaptive_states": cell.get("adaptive_state_distribution", {}),
        }

    # 1. Generate Markdown Table
    md_lines = [
        "# RAPID-RAG Experimental Results: Baseline & Policy Comparison\n",
        "| Policy | Policy Name | Workload | QPS | P50 Latency (ms) | P95 Latency (ms) | P99 Latency (ms) | SLO Compliance (%) | Load Imbalance |",
        "| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |",
    ]
    
    for pol in policies:
        for wk in workloads:
            cell = cell_map.get((pol, wk))
            if cell:
                md_lines.append(
                    f"| **{pol}** | {cell.get('policy_name')} | **{wk}** | "
                    f"{cell.get('qps', 0.0):.2f} | {cell.get('latency_p50_ms', 0.0):.1f} | "
                    f"{cell.get('latency_p95_ms', 0.0):.1f} | {cell.get('latency_p99_ms', 0.0):.1f} | "
                    f"{cell.get('slo_compliance_pct', 0.0):.1f}% | {cell.get('imbalance_ratio', 1.0):.2f} |"
                )
    md_text = "\n".join(md_lines) + "\n"
    (output_dir / "table_latency_slo_comparison.md").write_text(md_text, encoding="utf-8")
    
    # 2. Generate LaTeX Table
    tex_lines = [
        "\\begin{table}[htbp]",
        "\\centering",
        "\\caption{Performance, Latency Percentiles, and SLO Compliance Across Routing Policies}",
        "\\label{tab:rapid_rag_results}",
        "\\begin{tabular}{l|l|l|r|r|r|r|r|r}",
        "\\hline",
        "\\textbf{Policy} & \\textbf{Name} & \\textbf{Workload} & \\textbf{QPS} & \\textbf{P50 (ms)} & \\textbf{P95 (ms)} & \\textbf{P99 (ms)} & \\textbf{SLO (\\%)} & \\textbf{Imbalance} \\\\",
        "\\hline",
    ]
    
    for pol in policies:
        for wk in workloads:
            cell = cell_map.get((pol, wk))
            if cell:
                pname = cell.get('policy_name', pol).replace("&", "\\&")
                tex_lines.append(
                    f"{pol} & {pname} & {wk} & "
                    f"{cell.get('qps', 0.0):.2f} & {cell.get('latency_p50_ms', 0.0):.1f} & "
                    f"{cell.get('latency_p95_ms', 0.0):.1f} & {cell.get('latency_p99_ms', 0.0):.1f} & "
                    f"{cell.get('slo_compliance_pct', 0.0):.1f}\\% & {cell.get('imbalance_ratio', 1.0):.2f} \\\\"
                )
    tex_lines.extend([
        "\\hline",
        "\\end{tabular}",
        "\\end{table}",
    ])
    tex_text = "\n".join(tex_lines) + "\n"
    (output_dir / "table_latency_slo_comparison.tex").write_text(tex_text, encoding="utf-8")
    
    # 3. Write statistical_summary.json
    (output_dir / "statistical_summary.json").write_text(
        json.dumps(analysis_stats, indent=2) + "\n", encoding="utf-8"
    )
    
    print("\n================================================================================")
    print("DAY 7: STATISTICAL ANALYSIS & PAPER PACKAGE GENERATED!")
    print("================================================================================")
    print(f"Markdown Table: {output_dir / 'table_latency_slo_comparison.md'}")
    print(f"LaTeX Table:    {output_dir / 'table_latency_slo_comparison.tex'}")
    print(f"JSON Summary:   {output_dir / 'statistical_summary.json'}\n")
    return analysis_stats


def main():
    runs = load_all_runs(RUNS_DIR)
    if not runs:
        print(f"[ERROR] No experiment runs found in {RUNS_DIR}. Run scripts/run_experiment_matrix.py first.")
        sys.exit(1)
        
    print(f"Loaded {len(runs)} run summaries from {RUNS_DIR}")
    generate_paper_package(runs, OUTPUT_DIR)


if __name__ == "__main__":
    main()
