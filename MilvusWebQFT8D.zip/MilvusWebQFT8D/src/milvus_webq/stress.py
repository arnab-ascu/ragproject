from __future__ import annotations

import statistics
import time
from concurrent.futures import ThreadPoolExecutor

from .service import RAGService


def stress_queries(
    service: RAGService,
    queries: list[str],
    concurrency: int = 4,
    total_requests: int = 20,
    include_generation: bool = False,
    include_hyde: bool = False,
) -> dict:
    samples: list[tuple[float, str | None]] = []

    def run_one(index: int) -> tuple[float, str | None]:
        query = queries[index % len(queries)]
        started = time.perf_counter()
        try:
            if include_generation:
                service.answer(query, include_trace=False)
            else:
                retrieval_query = query
                if include_hyde and service.config.use_hyde:
                    retrieval_query = f"{query}\n\n{service.ollama.hyde(query)}"
                service.retriever.retrieve(query, retrieval_query)
            return (time.perf_counter() - started) * 1000, None
        except Exception as exc:
            return (time.perf_counter() - started) * 1000, str(exc)

    wall_started = time.perf_counter()
    with ThreadPoolExecutor(max_workers=concurrency) as executor:
        samples = list(executor.map(run_one, range(total_requests)))
    wall_seconds = time.perf_counter() - wall_started
    latencies = [latency for latency, error in samples if error is None]
    errors = [error for _, error in samples if error is not None]
    if not latencies:
        raise RuntimeError(f"All stress requests failed: {errors[:3]}")
    sorted_latencies = sorted(latencies)

    def percentile(p: float) -> float:
        if len(sorted_latencies) == 1:
            return sorted_latencies[0]
        index = round((p / 100) * (len(sorted_latencies) - 1))
        return sorted_latencies[index]

    return {
        "concurrency": concurrency,
        "requests": total_requests,
        "errors": len(errors),
        "qps": (total_requests - len(errors)) / wall_seconds,
        "mean_ms": statistics.mean(latencies),
        "p50_ms": percentile(50),
        "p95_ms": percentile(95),
        "p99_ms": percentile(99),
        "max_ms": max(latencies),
        "wall_seconds": wall_seconds,
        "include_generation": include_generation,
        "include_hyde": include_hyde,
    }
