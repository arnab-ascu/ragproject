from __future__ import annotations

import re

import numpy as np
from rank_bm25 import BM25Okapi


def tokenize(text: str) -> list[str]:
    return re.findall(r"\b[a-z0-9]+\b", text.lower())


class BM25Index:
    def __init__(self, doc_ids: list[str], texts: list[str]):
        self.doc_ids = doc_ids
        self.index = BM25Okapi([tokenize(text) for text in texts])

    def candidates(self, query: str, limit: int) -> tuple[list[str], dict[str, float]]:
        scores = self.index.get_scores(tokenize(query))
        positions = np.argsort(scores)[::-1][:limit]
        ids = [self.doc_ids[int(pos)] for pos in positions]
        score_by_id = {self.doc_ids[int(pos)]: float(scores[int(pos)]) for pos in positions}
        return ids, score_by_id
