# MilvusWebQ

Offline, LAN-deployable RAG pipeline using Docker Milvus, BEIR data, local
embedding/reranking models, HyDE query expansion, and local Ollama generation.

## Architecture

```
User Query
  -> External load balancer (Nginx or visible app-level route trace)
  -> Internal thread pool
  -> HyDE query expansion through local Ollama
  -> BM25 candidate filtering
  -> Dense vector search in Docker Milvus
  -> Cross-encoder reranking
  -> Query + retrieved sources sent to local Ollama
  -> Answer with source IDs/titles
```

## Why Docker Milvus matters

The vector DB should live inside the Milvus container/volume, not as a local
database file handed to an end user. A user interface should only call the API
or CLI and receive answers plus sources. Administrators operate the Milvus
server and runtime config.

## Final Containerized Deployment

This is the preferred internship/demo path. It runs Milvus, Ollama, two API
replicas, and an Nginx load balancer through Docker Compose.

```in-powershell
docker compose up -d --build
```

Services:

- `mwq-etcd`
- `mwq-minio`
- `mwq-milvus-standalone`
- `mwq-ollama`
- `mwq-api-a`
- `mwq-api-b`
- `mwq-nginx-lb`

The API containers mount local `data/` and `model_cache/` folders read-only, so
large data/model files are not copied into the image. Milvus stores vectors in
Docker volumes. Ollama stores local LLM weights in its own Docker volume.

Pull the local LLM into the Ollama container once:

```in-powershell
docker compose exec ollama ollama pull llama3.2
```

Health check through the load balancer:

```in-powershell
Invoke-RestMethod http://localhost:8080/health
```

Query through the load balancer:

```in-powershell
Invoke-RestMethod -Method Post http://localhost:8080/query `
  -ContentType "application/json" `
  -Body '{"query":"Impact of ambulance dispatch policies","include_trace":true}'
```

Open the plain web console:

```text
http://localhost:8080/gui
```

The GUI is intentionally thin. It calls the same backend endpoints used by the
CLI/API tests.

If old containers already occupy `19530`, `8000`, `8001`, or `8080`, stop them
or change ports in `.env`.

After changing API or Nginx configuration, recreate the API containers and
restart Nginx:

```in-powershell
docker compose up -d --build api-a api-b
docker compose restart nginx-lb
```

## Development Setup

Use this only when editing/debugging the Python code outside Docker.

```in-powershell
pip install -r requirements.txt
```

## Build a small vector collection

The default config indexes only `1000` BEIR `scidocs` documents to avoid a
long rebuild.

```in-powershell
python scripts/ingest_subset.py --rebuild
```

This creates a collection named like:

```
internship_rag_scidocs_1000_sentence_transformers_all_mpnet_base_v2_768
```

Each embedding model gets a separate collection because embedding dimensions
and vector spaces are not interchangeable.

## User interface

The user only asks and receives an answer with sources:

```in-powershell
$env:PYTHONPATH="src"
python -m milvus_webq.interfaces.user_cli "Impact of ambulance dispatch policies"
```

Add `--trace` when demonstrating load-balancing and timings.

## Administrator interface

View settings:

```powershell
$env:PYTHONPATH="src"
python -m milvus_webq.interfaces.admin_cli show
```

Change a runtime value:

```powershell
$env:PYTHONPATH="src"
python -m milvus_webq.interfaces.admin_cli set final_top_k 3 --persist
```

Available model knobs are in `config/settings.yaml`. Extra model names are
listed there, but offline mode requires those models to exist in
`model_cache` or Ollama before switching.

Inside Docker:

```powershell
docker compose exec api-a python scripts/ingest_subset.py --rebuild
```

## API interface

Docker load-balanced endpoint:

```powershell
http://localhost:8080
```

Individual API replicas are also mapped for inspection:

```text
http://localhost:8000 -> api-a
http://localhost:8001 -> api-b
```

Query:

```powershell
Invoke-RestMethod -Method Post http://localhost:8080/query `
  -ContentType "application/json" `
  -Body '{"query":"Impact of ambulance dispatch policies","include_trace":true}'
```

Stress test:

```powershell
Invoke-RestMethod -Method Post http://localhost:8080/stress `
  -ContentType "application/json" `
  -Body '{"concurrency":4,"total_requests":20,"include_generation":false}'
```

## RAPID-RAG Day 1: end-to-end baseline capture

Use `scripts/stress_end_to_end.py` for routing experiments. Unlike `/stress`,
it is an external HTTP client: every request traverses Nginx on port 8080 and
the saved trace records whether `api-a` or `api-b` handled it. It writes a
per-request CSV, lossless JSONL, and a run summary without changing the Milvus
collection.

```powershell
python scripts/stress_end_to_end.py --workload S --concurrency 2 --requests 20
```

`S` is the low-cost routing test workload: retrieval only, with HyDE and the
reranker disabled. `M` adds the reranker, `L` adds HyDE while staying
retrieval-only, `XL` uses full RAG, and `MIX` samples all four. Results are
written to `results/runs/<timestamp>/` by default. For a repeatable baseline,
keep the seed fixed (the default), use the same query file and workload for
each run, and retain `requests.csv`, `requests.jsonl`, and `summary.json`.

The browser console now exposes the same per-request controls: **Retrieval
Only** skips answer generation entirely, while HyDE and each LLM token budget
can be changed for a single request without altering persisted runtime
settings. The `/query` request accepts `execution_mode`, `include_hyde`,
`use_reranker`, `llm_num_predict`, and `hyde_num_predict`; all effective values
are included in `trace.request_profile`.

## RAPID-RAG Day 2: predictive ingress routing

Nginx now sends queries to a single scheduler ingress, which chooses `api-a`
or `api-b` before forwarding the request. This is essential: an API replica
cannot make a meaningful replica decision after Nginx has already selected it.
The scheduler supports `round_robin`, `least_conn`, and `rapid` modes. RAPID
maintains per-replica, per-execution-profile stage EWMAs and active-request
work estimates; during cold start it confidence-blends its predicted completion
time with least-connections. Each response trace includes the selected backend,
candidate estimates, confidence, and reason.

Choose a one-off policy in the GUI's Router control or run a controlled client
experiment:

```powershell
python scripts/stress_end_to_end.py --workload S --scheduler-mode rapid --concurrency 2 --requests 20
```

Inspect the live telemetry at `http://localhost:8080/scheduler/telemetry`.
The persistent defaults are in `config/settings.yaml`; leave
`scheduler_mode: "least_conn"` for the Day-1 baseline and use `rapid` for
Day-2 runs.

## RAPID-RAG Day 3: model-aware profiles

The scheduler now discovers model tags from Ollama's `/api/tags` endpoint at
`/scheduler/models`. The GUI replaces configured model names with the actually
installed tags when that endpoint is reachable, and an explicitly requested
missing model receives a clear `422` response instead of a slow generation
failure. Telemetry additionally aggregates stage EWMAs per model and replica.

Collect comparable warm model profiles with the same query and token budget:

```powershell
python scripts/profile_models.py --iterations 2 --llm-num-predict 64 --no-hyde
```

The script discovers installed models, writes one lossless record per
model/iteration, and produces a summary in `results/model_profiles/`. Use only
installed tags in formal comparisons; configured names are merely suggestions.

## External load balancing demo

`infra/nginx-load-balancer.conf` routes port `8080` to the two API containers.
`/query` with `include_trace:true` also returns:

- `external_backend`: API replica/backend identity
- `internal_worker`: actual Python thread that handled the pipeline
- stage timings

## GUI integration

A future GUI can call either:

- `RAGService.answer(query)` directly from Python
- `POST /query` over HTTP

That keeps the GUI separate from Milvus, model loading, retrieval, reranking,
and generation internals.
