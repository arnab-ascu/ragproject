from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from milvus_webq.config import load_config
from milvus_webq.service import RAGService
from milvus_webq.stress import stress_queries


def main() -> None:
    parser = argparse.ArgumentParser(description="Threaded API-style stress test.")
    parser.add_argument("--concurrency", type=int, default=4)
    parser.add_argument("--requests", type=int, default=20)
    parser.add_argument("--generation", action="store_true")
    parser.add_argument("--hyde", action="store_true")
    args = parser.parse_args()

    service = RAGService(load_config())
    queries = [service.bundle.queries[qid] for qid in service.bundle.query_ids[:10]]
    print(json.dumps(stress_queries(service, queries, args.concurrency, args.requests, args.generation, args.hyde), indent=2))


if __name__ == "__main__":
    main()
