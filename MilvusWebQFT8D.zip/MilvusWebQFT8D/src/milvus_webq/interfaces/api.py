from __future__ import annotations

from dataclasses import asdict
from pathlib import Path
from typing import Any, Literal

import requests
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from pymilvus import MilvusClient

from milvus_webq.admin import AdminState
from milvus_webq.config import load_config
from milvus_webq.milvus_store import collection_name
from milvus_webq.service import RAGService
from milvus_webq.stress import stress_queries


app = FastAPI(title="MilvusWebQ Offline RAG API", version="0.1.0")
admin = AdminState(load_config())
service: RAGService | None = None
STATIC_DIR = Path(__file__).resolve().parents[1] / "static"

app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


class QueryRequest(BaseModel):
    query: str
    include_trace: bool = False
    llm_model: str | None = None
    execution_mode: Literal["retrieval_only", "full_rag"] = "full_rag"
    include_hyde: bool | None = None
    use_reranker: bool | None = None
    llm_num_predict: int | None = Field(default=None, ge=1, le=4096)
    hyde_num_predict: int | None = Field(default=None, ge=1, le=2048)


class ConfigUpdate(BaseModel):
    values: dict[str, Any]
    persist: bool = False
    reload_service: bool = True


class StressRequest(BaseModel):
    queries: list[str] = Field(default_factory=list)
    concurrency: int = 4
    total_requests: int = 20
    include_generation: bool = False
    include_hyde: bool = False


def get_service() -> RAGService:
    global service
    if service is None:
        service = RAGService(admin.config)
    return service


@app.get("/", response_class=HTMLResponse)
def root() -> HTMLResponse:
    return HTMLResponse((STATIC_DIR / "index.html").read_text(encoding="utf-8"))


@app.get("/gui", response_class=HTMLResponse)
def gui() -> HTMLResponse:
    return HTMLResponse((STATIC_DIR / "index.html").read_text(encoding="utf-8"))


@app.get("/health")
def health() -> dict:
    name = collection_name(admin.config, admin.config.embedding_dim)
    rows: int | str = "unavailable"
    try:
        svc = get_service()
        rows = svc.store.row_count()
    except Exception as exc:
        rows = f"milvus check failed: {exc}"
    return {
        "status": "ok",
        "collection": name,
        "rows": rows,
        "config": {
            "milvus_uri": admin.config.milvus_uri,
            "embedding_model": admin.config.embedding_model,
            "llm_model": admin.config.llm_model,
            "document_limit": admin.config.document_limit,
        },
    }


@app.post("/query")
def query(request: QueryRequest) -> dict:
    return get_service().answer(
        request.query,
        include_trace=request.include_trace,
        llm_model=request.llm_model,
        execution_mode=request.execution_mode,
        include_hyde=request.include_hyde,
        use_reranker=request.use_reranker,
        llm_num_predict=request.llm_num_predict,
        hyde_num_predict=request.hyde_num_predict,
    )


@app.get("/admin/config")
def view_config() -> dict:
    return asdict(admin.config)


@app.post("/admin/reload")
def reload_config() -> dict:
    global admin, service
    admin = AdminState(load_config())
    service = None
    return asdict(admin.config)


def _notify_peers() -> list[dict]:
    results = []
    for peer_url in admin.config.peer_backends:
        try:
            resp = requests.post(f"{peer_url.rstrip('/')}/admin/reload", timeout=5)
            results.append({"peer": peer_url, "status": resp.status_code})
        except requests.RequestException as exc:
            results.append({"peer": peer_url, "error": str(exc)})
    return results


@app.post("/admin/config")
def update_config(request: ConfigUpdate) -> dict:
    global service
    updated = admin.update(request.values, persist=request.persist)
    if request.reload_service:
        service = None
    if request.persist:
        updated["_peer_sync"] = _notify_peers()
    return updated


@app.post("/admin/ensure-indexed")
def ensure_indexed(rebuild: bool = False) -> dict:
    return get_service().ensure_indexed(rebuild=rebuild)


@app.post("/stress")
def stress(request: StressRequest) -> dict:
    svc = get_service()
    queries = request.queries or [
        svc.bundle.queries[qid]
        for qid in svc.bundle.query_ids[: min(10, len(svc.bundle.query_ids))]
    ]
    return stress_queries(
        svc,
        queries=queries,
        concurrency=request.concurrency,
        total_requests=request.total_requests,
        include_generation=request.include_generation,
        include_hyde=request.include_hyde,
    )


class AdaptiveToggleRequest(BaseModel):
    enabled: bool


@app.get("/admin/adaptive")
def view_adaptive_status() -> dict:
    return get_service().adaptive_controller.snapshot()


@app.post("/admin/adaptive/toggle")
def toggle_adaptive(request: AdaptiveToggleRequest) -> dict:
    svc = get_service()
    svc.config.adaptive_budget = request.enabled
    svc.adaptive_controller.config.adaptive_budget = request.enabled
    return svc.adaptive_controller.snapshot()


@app.post("/admin/export-config")
def export_experiment_config() -> dict:
    import json
    from datetime import datetime, timezone
    from milvus_webq.config import PROJECT_ROOT

    svc = get_service()
    export_dir = PROJECT_ROOT / "results" / "experiment_configs"
    export_dir.mkdir(parents=True, exist_ok=True)
    filename = f"experiment_config_{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S')}.json"
    filepath = export_dir / filename

    bundle = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "config": asdict(svc.config),
        "adaptive_snapshot": svc.adaptive_controller.snapshot(),
    }
    filepath.write_text(json.dumps(bundle, indent=2) + "\n", encoding="utf-8")
    return {"status": "exported", "filepath": str(filepath), "bundle": bundle}


