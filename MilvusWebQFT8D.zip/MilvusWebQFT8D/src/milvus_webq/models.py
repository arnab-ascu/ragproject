from __future__ import annotations

import requests

from .config import PROJECT_ROOT, RuntimeConfig


class EmbeddingModel:
    def __init__(self, config: RuntimeConfig):
        from sentence_transformers import SentenceTransformer

        self.config = config
        self.model = SentenceTransformer(
            config.embedding_model,
            cache_folder=str(PROJECT_ROOT / "model_cache" / "hub"),
            local_files_only=config.offline_mode,
        )
        self.dim = self.model.get_sentence_embedding_dimension()

    def encode(self, texts: list[str], batch_size: int | None = None) -> list[list[float]]:
        vectors = self.model.encode(
            texts,
            batch_size=batch_size or self.config.encode_batch_size,
            normalize_embeddings=True,
            show_progress_bar=False,
        )
        return vectors.tolist()


class CrossEncoderReranker:
    def __init__(self, config: RuntimeConfig):
        self.config = config
        self.model = None

    def _load(self):
        from sentence_transformers import CrossEncoder

        if self.model is None:
            self.model = CrossEncoder(
                self.config.crossencoder_model,
                cache_folder=str(PROJECT_ROOT / "model_cache" / "hub"),
                max_length=512,
                local_files_only=self.config.offline_mode,
            )
        return self.model

    def rerank(self, query: str, results: list[dict], top_k: int) -> list[dict]:
        if not results:
            return []
        pairs = [
            (query, f"{item.get('title', '')}\n\n{item.get('text', '')}".strip())
            for item in results
        ]
        scores = self._load().predict(pairs)
        reranked = [
            {**item, "rerank_score": float(score)}
            for item, score in zip(results, scores)
        ]
        return sorted(reranked, key=lambda item: item["rerank_score"], reverse=True)[:top_k]


class OllamaClient:
    def __init__(self, config: RuntimeConfig):
        self.config = config

    def generate(
        self,
        prompt: str,
        model: str | None = None,
        num_predict: int | None = None,
    ) -> str:
        payload = {
            "model": model or self.config.llm_model,
            "prompt": prompt,
            "stream": False,
            "options": {
                "num_predict": num_predict or self.config.llm_num_predict,
            },
        }
        response = requests.post(self.config.ollama_url, json=payload, timeout=180)
        response.raise_for_status()
        return response.json().get("response", "").strip()

    def hyde(
        self,
        query: str,
        model: str | None = None,
        num_predict: int | None = None,
    ) -> str:
        prompt = (
            "Write one concise hypothetical academic passage that would answer "
            "the user query. Do not add citations.\n\nQuery: "
            f"{query}\n\nPassage:"
        )
        try:
            return self.generate(
                prompt,
                model=model,
                num_predict=num_predict or self.config.hyde_num_predict,
            )
        except requests.RequestException:
            return query
