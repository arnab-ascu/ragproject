"""Evaluate dense-only and hybrid retrieval quality against BEIR qrels.

Reuses the real production components (MilvusStore, BM25Index,
CrossEncoderReranker, EmbeddingModel) so the numbers reflect the
actual deployed pipeline, not a separate notebook implementation.

Run inside the api-a container so it can reach Milvus on the internal
Docker network:

    docker compose exec api-a python scripts/evaluate_retrieval.py
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

import pandas as pd
from beir.retrieval.evaluation import EvaluateRetrieval
from tqdm.auto import tqdm

from milvus_webq.bm25 import BM25Index
from milvus_webq.config import load_config
from milvus_webq.data import load_beir_bundle
from milvus_webq.milvus_store import MilvusStore
from milvus_webq.models import CrossEncoderReranker, EmbeddingModel
from milvus_webq.retrieval import HybridRetriever

K_VALUES = [1, 3, 5, 10, 100]


def evaluate(name: str, search_fn, queries, qrels, query_ids, top_k: int = 100):
    results = {}
    for qid in tqdm(query_ids, desc=f"Evaluating ({name})"):
        hits = search_fn(queries[qid], top_k)
        results[qid] = {hit["doc_id"]: hit["score"] for hit in hits}

    selected_qrels = {qid: qrels[qid] for qid in query_ids}
    ndcg, map_scores, recall, precision = EvaluateRetrieval.evaluate(
        selected_qrels, results, K_VALUES
    )
    mrr = EvaluateRetrieval.evaluate_custom(
        selected_qrels, results, K_VALUES, metric="mrr"
    )
    metrics = {**ndcg, **map_scores, **recall, **precision, **mrr}
    return pd.Series(metrics).sort_index()


def main():
    config = load_config()
    bundle = load_beir_bundle(config)
    print(f"Loaded {len(bundle.corpus_ids)} docs, {len(bundle.query_ids)} scored queries")

    embedder = EmbeddingModel(config)
    store = MilvusStore(config, embedder)
    bm25 = BM25Index(bundle.corpus_ids, bundle.corpus_texts)
    reranker = CrossEncoderReranker(config)
    retriever = HybridRetriever(config, embedder, store, bm25, reranker)

    def dense_search(query: str, top_k: int):
        vector = embedder.encode([query])[0]
        return store.search_vector(vector, top_k=top_k, candidate_ids=None)

    def hybrid_search(query: str, top_k: int):
        # retrieve() gates results at rerank_top_k then final_top_k, and
        # candidates at search_top_k before that — all three must be
        # widened to top_k or NDCG/Recall/Precision @10 and @100 would
        # be silently capped at the configured default (3), understating
        # hybrid quality rather than reflecting the pipeline's real ceiling.
        original = (config.final_top_k, config.rerank_top_k, config.search_top_k)
        config.final_top_k = top_k
        config.rerank_top_k = top_k
        config.search_top_k = max(config.search_top_k, top_k)
        try:
            results, _ = retriever.retrieve(query)
        finally:
            config.final_top_k, config.rerank_top_k, config.search_top_k = original
        return results

    dense_metrics = evaluate(
        "dense-only", dense_search, bundle.queries, bundle.qrels, bundle.query_ids
    )
    print("\n=== Dense-only retrieval (Table 7.1) ===")
    print(dense_metrics)

    hybrid_metrics = evaluate(
        "hybrid", hybrid_search, bundle.queries, bundle.qrels, bundle.query_ids
    )
    print("\n=== Hybrid retrieval: BM25 + dense + rerank (Table 7.2) ===")
    print(hybrid_metrics)

    out_dir = Path(__file__).resolve().parents[1] / "results"
    out_dir.mkdir(exist_ok=True)
    dense_metrics.to_csv(out_dir / "dense_only_metrics.csv")
    hybrid_metrics.to_csv(out_dir / "hybrid_metrics.csv")
    print(f"\nSaved CSVs to {out_dir}")


if __name__ == "__main__":
    main()