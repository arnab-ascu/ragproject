# LLM Navigation & Documentation Guide: RAPID-RAG System

> **Instructions for AI Assistants / ChatGPT**:
> This document serves as a comprehensive map and index of the entire `MilvusWebQFT` repository.
> If you are tasked with generating documentation, technical whitepapers, research papers, developer guides, or API specifications, use the file index, architecture overview, and benchmark results documented below.

---

## 1. Executive Summary & Project Purpose

**RAPID-RAG** is a latency-aware, load-adaptive Retrieval-Augmented Generation (RAG) system built on top of a 25,657-document SciDocs vector collection stored in a standalone Milvus database. 

It addresses high latency tail spikes and SLO violations under heavy query concurrency by dynamically adjusting RAG execution budgets (HyDE depth, dense vector top-k, BM25 top-k, cross-encoder reranking count, and LLM output token limits) based on real-time EWMA latency telemetry and hysteresis load indexing.

---

## 2. Directory Structure & Key Files Index

```text
MilvusWebQFT/
├── config/
│   └── settings.yaml                      # System parameters, Milvus URI, vector collection name, model parameters
├── docker-compose.yml                     # Multi-container orchestration (8 services)
├── nginx/
│   └── nginx.conf                         # Round-robin & least-connections load balancer configuration (Port 8080)
├── README_FOR_LLM.md                      # [THIS FILE] LLM navigation guide for automated documentation creation
├── results/                               # Benchmark runs, config exports, and paper deliverables
│   ├── experiment_configs/                # JSON snapshots exported via /admin/export-config
│   ├── paper_package/                     # Camera-ready publication deliverables
│   │   ├── statistical_summary.json       # Aggregate statistical metrics across policies & workloads
│   │   ├── table_latency_slo_comparison.md# Markdown benchmark results table
│   │   └── table_latency_slo_comparison.tex# LaTeX IEEE/ACM table
│   └── runs/                              # Raw request traces & summary metrics per cell
│       ├── experiment_matrix_summary.csv  # Master CSV matrix summary across all 20 cells
│       └── experiment_matrix_summary.json # Master JSON matrix summary across all 20 cells
├── scripts/                               # Operational & benchmarking CLI tools
│   ├── analyze_experiments.py             # Statistical analysis script (generates results/paper_package/)
│   ├── evaluate_retrieval.py              # Precision, Recall, and MRR evaluation on SciDocs ground truth
│   ├── profile_models.py                  # Model tag discovery & prompt/token latency profiler
│   ├── run_experiment_matrix.py           # Benchmark runner evaluating policies (B0-B3) x workloads (S-MIX)
│   ├── stress_end_to_end.py               # Traffic generator sending parameterized synthetic workloads
│   └── verify_day8_package.py             # System verification & audit script
└── src/
    └── milvus_webq/                       # Core Python package implementation
        ├── adaptive_budget.py             # Hysteresis AdaptiveBudgetController & LoadIndex evaluation
        ├── config.py                      # YAML settings parser and configuration data classes
        ├── interfaces/
        │   └── api.py                     # FastAPI REST API endpoints (/query, /health, /admin/adaptive, /admin/export-config)
        ├── model_catalog.py               # Ollama model discovery & execution parameter mapping
        ├── models.py                      # Vector embedding model loader (SentenceTransformers all-mpnet-base-v2)
        ├── scheduler.py                   # Stage-aware RAPID telemetry scheduler (Port 8002)
        ├── service.py                     # Core RAG pipeline logic (HyDE, Dense, BM25, Reranker, LLM execution)
        ├── static/                        # Administrative Web Console GUI
        │   ├── app.js                     # Live UI logic (2s polling, status badge, toggle switch, export button)
        │   ├── index.html                 # Main dashboard UI
        │   └── styles.css                 # Custom glassmorphism dark-mode CSS design system
        ├── store.py                       # Milvus standalone vector store interface
        └── telemetry.py                   # EWMA stage timing estimator & confidence blending
```

---

## 3. Key Technical Concepts & Math Formulations

### A. Load Index Calculation
The `AdaptiveBudgetController` ([`src/milvus_webq/adaptive_budget.py`](file:///c:/Users/arnab/Desktop/MilvusWebQFT/src/milvus_webq/adaptive_budget.py)) continuously tracks active query concurrency and mean execution latency to compute system load:

$$\text{LoadIndex} = \frac{\text{ActiveRequests}}{\text{CapacityLimit}} + 0.3 \times \min\left(1.0, \frac{\text{MeanLatencyMs}}{\text{SLOTargetMs}}\right)$$

### B. Hysteresis State Transitions
To prevent rapid budget oscillation near state boundaries, hysteresis thresholds are enforced:
- **`NORMAL`** ($\text{LoadIndex} < 0.45$): Full budget (HyDE ON, BM25 150, Dense 30, Rerank Top 3, LLM Tokens 220).
- **`BUSY`** ($\text{LoadIndex} \ge 0.60$ enter, $\le 0.50$ exit): Reduced budget (HyDE ON, BM25 100, Dense 20, Rerank Top 3, LLM Tokens 128).
- **`SATURATED`** ($\text{LoadIndex} \ge 0.80$ enter, $\le 0.65$ exit): Fast budget (HyDE OFF, BM25 50, Dense 10, Rerank Top 2, LLM Tokens 64).

### C. EWMA Stage Estimator
The `StageEstimator` ([`src/milvus_webq/telemetry.py`](file:///c:/Users/arnab/Desktop/MilvusWebQFT/src/milvus_webq/telemetry.py)) maintains exponential moving averages ($\alpha = 0.2$) for RAG pipeline stages:

$$\hat{T}_{\text{stage}} \leftarrow (1 - \alpha) \cdot \hat{T}_{\text{stage}} + \alpha \cdot T_{\text{measured}}$$

---

## 4. Benchmark Policies & Workload Profiles

### Benchmark Policies Evaluated
1. **`B0` (Round-Robin)**: Static round-robin distribution via Nginx LB.
2. **`B1` (Least-Connections)**: Dynamic least-connections routing via Nginx LB.
3. **`B2` (RAPID v0)**: Telemetry-aware estimated execution routing without adaptive budgeting.
4. **`B3` (RAPID + Adaptive Budgets)**: Full RAPID scheduling combined with dynamic hysteresis load-adaptive budgeting.

### Workload Profiles
- **`S` (Small)**: Direct retrieval only (dense + BM25, no LLM generation).
- **`M` (Medium)**: Short RAG (HyDE OFF, dense + BM25, 64 LLM tokens).
- **`L` (Large)**: Deep RAG (HyDE ON, top-20 dense, rerank top-3, 128 LLM tokens).
- **`XL` (Extra Large)**: Heavy multi-hop RAG (HyDE ON, top-30 dense, rerank top-5, 220 LLM tokens).
- **`MIX` (Mixed Workload)**: Probabilistic distribution ($20\% \text{ S}, 30\% \text{ M}, 30\% \text{ L}, 20\% \text{ XL}$).

---

## 5. Key Results Summary for Documentation Generation

When writing documentation or paper results from this repository:
1. **Primary Benchmark Deliverable**: Inspect [`results/paper_package/table_latency_slo_comparison.md`](file:///c:/Users/arnab/Desktop/MilvusWebQFT/results/paper_package/table_latency_slo_comparison.md) for the Markdown table of QPS, P50, P95, P99, and SLO compliance.
2. **Statistical Breakdown**: Inspect [`results/paper_package/statistical_summary.json`](file:///c:/Users/arnab/Desktop/MilvusWebQFT/results/paper_package/statistical_summary.json) for mean, standard deviation, min, max, and sample counts across all policy runs.
3. **Raw Log Files**: Individual request timing traces are available as CSV and JSON in [`results/runs/`](file:///c:/Users/arnab/Desktop/MilvusWebQFT/results/runs/).

---

## 6. Commands to Run & Verify

```powershell
# 1. Start full Docker stack
docker compose up -d

# 2. Audit system health and 25,657 Milvus collection documents
python -c "import urllib.request; print(urllib.request.urlopen('http://localhost:8080/health').read().decode())"

# 3. Execute master Day 1-8 verification auditor
python scripts/verify_day8_package.py

# 4. Regenerate research paper tables & statistical packages
python scripts/analyze_experiments.py
```
