from __future__ import annotations

import argparse
import json

from milvus_webq.admin import AdminState


def parse_value(raw: str):
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return raw


def main() -> None:
    parser = argparse.ArgumentParser(description="Administrator interface for runtime settings.")
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("show", help="Print current settings")
    set_parser = subparsers.add_parser("set", help="Set one runtime setting")
    set_parser.add_argument("key")
    set_parser.add_argument("value")
    set_parser.add_argument("--persist", action="store_true", help="Write change to config/settings.yaml")
    args = parser.parse_args()

    admin = AdminState()
    if args.command == "show":
        print(json.dumps(admin.view(), indent=2))
        return
    updated = admin.update({args.key: parse_value(args.value)}, persist=args.persist)
    print(json.dumps(updated, indent=2))


if __name__ == "__main__":
    main()
