from __future__ import annotations


CONFIDENCE_THRESHOLD = 2.0  # rerank_score above this = high retrieval confidence


def answer_prompt(query: str, results: list[dict], max_source_chars: int = 900) -> str:
    context_parts = []
    high_confidence = False
    for index, result in enumerate(results, start=1):
        title = result.get("title", "Unknown title")
        doc_id = result.get("doc_id", "unknown")
        text = (result.get("text", "") or "")[:max_source_chars]
        rerank_score = result.get("rerank_score")
        if rerank_score is not None and rerank_score >= CONFIDENCE_THRESHOLD:
            high_confidence = True
        context_parts.append(
            f"--- Source {index} ---\nTitle: {title}\nID: {doc_id}\nContent: {text}"
        )
    context = "\n\n".join(context_parts)

    confidence_note = (
        "\nNote: the top source has a high cross-encoder relevance score, meaning "
        "the retrieval system has strong confidence this source is topically "
        "relevant to the query. Weigh this signal when deciding whether the "
        "source supports an answer, but still verify the source's actual content "
        "supports the specific claim in the query before answering from it.\n"
        if high_confidence
        else ""
    )

    return f"""You are an academic research assistant.
Use ONLY the retrieved sources below. If the sources do not contain the answer,
say that the answer is not available in the retrieved documents.

Sources may describe the same concept using different technical terminology
than the query. Before concluding a source is irrelevant, consider whether it
expresses the same underlying concept using domain-specific synonyms or
paraphrases (e.g. "nonsmooth fuel cost function" and "valve-point effect" both
refer to the same phenomenon in power systems literature). Reason about
conceptual/semantic equivalence, not just literal keyword overlap.
{confidence_note}
Retrieved sources:
{context}

User query: {query}

Return exactly:
Answer: <clear answer>
Source: <source title and ID values used>
"""