from __future__ import annotations

import time
from dataclasses import asdict

from .adaptive_budget import AdaptiveBudgetController
from .bm25 import BM25Index
from .config import RuntimeConfig
from .data import load_beir_bundle
from .load_balancer import ExternalLoadBalancer, InternalThreadPool, RouteTrace
from .milvus_store import MilvusStore
from .models import CrossEncoderReranker, EmbeddingModel, OllamaClient
from .prompts import answer_prompt
from .retrieval import HybridRetriever


class RAGService:
    def __init__(self, config: RuntimeConfig):
        self.config = config
        self.bundle = load_beir_bundle(config)
        self.embedder = EmbeddingModel(config)
        self.store = MilvusStore(config, self.embedder)
        self.store.setup(rebuild=False)
        self.bm25 = BM25Index(self.bundle.corpus_ids, self.bundle.corpus_texts)
        self.reranker = CrossEncoderReranker(config)
        self.ollama = OllamaClient(config)
        self.retriever = HybridRetriever(config, self.embedder, self.store, self.bm25, self.reranker)
        self.external_lb = ExternalLoadBalancer(config)
        self.internal_pool = InternalThreadPool(config.max_workers)
        self.adaptive_controller = AdaptiveBudgetController(config)

    def ensure_indexed(self, rebuild: bool = False) -> dict[str, float]:
        return self.store.ingest(self.bundle, rebuild=rebuild)

    def answer(
        self,
        query: str,
        include_trace: bool = False,
        llm_model: str | None = None,
        execution_mode: str = "full_rag",
        include_hyde: bool | None = None,
        use_reranker: bool | None = None,
        llm_num_predict: int | None = None,
        hyde_num_predict: int | None = None,
    ) -> dict:
        if execution_mode not in {"retrieval_only", "full_rag"}:
            raise ValueError("execution_mode must be 'retrieval_only' or 'full_rag'")
        if llm_num_predict is not None and llm_num_predict < 1:
            raise ValueError("llm_num_predict must be positive")
        if hyde_num_predict is not None and hyde_num_predict < 1:
            raise ValueError("hyde_num_predict must be positive")

        self.adaptive_controller.record_start()
        external_backend = self.external_lb.choose_backend()
        started = time.perf_counter()
        target_model = llm_model or self.config.llm_model

        adaptive_state, load_index, effective = self.adaptive_controller.get_effective_params(
            request_include_hyde=include_hyde,
            request_use_reranker=use_reranker,
            request_llm_num_predict=llm_num_predict,
            request_hyde_num_predict=hyde_num_predict,
        )
        hyde_enabled = effective["use_hyde"]
        reranker_enabled = effective["use_reranker"]
        bm25_candidates = effective["bm25_candidates"]
        search_top_k = effective["search_top_k"]
        rerank_top_k = effective["rerank_top_k"]
        answer_token_budget = effective["llm_num_predict"]
        hyde_token_budget = effective["hyde_num_predict"]

        def pipeline() -> dict:
            stage_started = time.perf_counter()
            retrieval_query = query
            hyde_text = None
            if hyde_enabled:
                hyde_text = self.ollama.hyde(
                    query,
                    model=target_model,
                    num_predict=hyde_token_budget,
                )
                retrieval_query = f"{query}\n\n{hyde_text}"
            hyde_ms = (time.perf_counter() - stage_started) * 1000

            retrieved_at = time.perf_counter()
            results, retrieval_trace = self.retriever.retrieve(
                query,
                retrieval_query,
                use_reranker=reranker_enabled,
                bm25_candidates=bm25_candidates,
                search_top_k=search_top_k,
                rerank_top_k=rerank_top_k,
            )
            retrieval_ms = (time.perf_counter() - retrieved_at) * 1000

            generation_error = None
            generation_ms = 0.0
            if execution_mode == "retrieval_only":
                answer = "Retrieval-only mode: answer generation was skipped."
            else:
                generated_at = time.perf_counter()
                try:
                    answer = self.ollama.generate(
                        answer_prompt(
                            query,
                            results,
                            max_source_chars=self.config.max_source_chars,
                        ),
                        model=target_model,
                        num_predict=answer_token_budget,
                    )
                except Exception as exc:
                    generation_error = str(exc)
                    answer = (
                        "Answer: Local LLM generation is unavailable, but retrieval succeeded. "
                        "Start Ollama and retry for synthesis.\n"
                        "Source: "
                        + "; ".join(
                            f"{item.get('title')} ({item.get('doc_id')})"
                            for item in results
                        )
                    )
                generation_ms = (time.perf_counter() - generated_at) * 1000
            return {
                "query": query,
                "answer": answer,
                "sources": [
                    {
                        "doc_id": item.get("doc_id"),
                        "title": item.get("title"),
                        "score": item.get("score"),
                        "bm25_score": item.get("bm25_score"),
                        "rerank_score": item.get("rerank_score"),
                    }
                    for item in results
                ],
                "trace": {
                    "execution_mode": execution_mode,
                    "request_profile": {
                        "model": target_model,
                        "include_hyde": hyde_enabled,
                        "use_reranker": reranker_enabled,
                        "bm25_candidates": bm25_candidates,
                        "dense_top_k": search_top_k,
                        "rerank_top_k": rerank_top_k,
                        "llm_num_predict": answer_token_budget,
                        "hyde_num_predict": hyde_token_budget,
                    },
                    "adaptive": {
                        "profile": adaptive_state.value if hasattr(adaptive_state, "value") else str(adaptive_state),
                        "load_index": load_index,
                        "effective_budget": effective,
                    },
                    "hyde_used": hyde_enabled,
                    "hyde_text": hyde_text if include_trace else None,
                    "retrieval": asdict(retrieval_trace),
                    "timings_ms": {
                        "hyde": hyde_ms,
                        "retrieval": retrieval_ms,
                        "generation": generation_ms,
                    },
                    "generation_error": generation_error,
                },
            }

        try:
            payload, worker = self.internal_pool.run(pipeline)
            payload["trace"]["route"] = asdict(RouteTrace(external_backend, worker))
            total_ms = (time.perf_counter() - started) * 1000
            payload["trace"]["total_ms"] = total_ms
            if not include_trace:
                payload.pop("trace", None)
            return payload
        finally:
            total_ms = (time.perf_counter() - started) * 1000
            self.adaptive_controller.record_finish(total_ms)
