from __future__ import annotations

from dataclasses import dataclass

from .bm25 import BM25Index
from .config import RuntimeConfig
from .milvus_store import MilvusStore
from .models import CrossEncoderReranker, EmbeddingModel


@dataclass
class RetrievalTrace:
    original_query: str
    retrieval_query: str
    bm25_candidates: int
    dense_top_k: int
    reranked: bool
    collection: str


class HybridRetriever:
    def __init__(
        self,
        config: RuntimeConfig,
        embedder: EmbeddingModel,
        store: MilvusStore,
        bm25: BM25Index,
        reranker: CrossEncoderReranker,
    ):
        self.config = config
        self.embedder = embedder
        self.store = store
        self.bm25 = bm25
        self.reranker = reranker

    def retrieve(
        self,
        original_query: str,
        retrieval_query: str | None = None,
        use_reranker: bool | None = None,
        bm25_candidates: int | None = None,
        search_top_k: int | None = None,
        rerank_top_k: int | None = None,
        final_top_k: int | None = None,
    ) -> tuple[list[dict], RetrievalTrace]:
        effective_query = retrieval_query or original_query
        reranker_enabled = self.config.use_reranker if use_reranker is None else use_reranker
        bm25_limit = bm25_candidates or self.config.bm25_candidates
        dense_limit = search_top_k or self.config.search_top_k
        rerank_limit = rerank_top_k or self.config.rerank_top_k
        final_limit = final_top_k or self.config.final_top_k

        candidate_ids, bm25_scores = self.bm25.candidates(
            effective_query,
            limit=bm25_limit,
        )
        query_vector = self.embedder.encode([effective_query])[0]
        results = self.store.search_vector(
            query_vector,
            top_k=dense_limit,
            candidate_ids=candidate_ids,
        )
        for result in results:
            result["bm25_score"] = bm25_scores.get(result["doc_id"], 0.0)
        if reranker_enabled:
            results = self.reranker.rerank(
                original_query,
                results,
                top_k=rerank_limit,
            )
        else:
            results = results[: final_limit]
        trace = RetrievalTrace(
            original_query=original_query,
            retrieval_query=effective_query,
            bm25_candidates=len(candidate_ids),
            dense_top_k=dense_limit,
            reranked=reranker_enabled,
            collection=self.store.name,
        )
        return results[: final_limit], trace
