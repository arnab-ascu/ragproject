"""Single ingress scheduler that makes RAPID's replica choice executable."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Literal

import requests
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from milvus_webq.config import load_config
from milvus_webq.model_catalog import ModelCatalog
from milvus_webq.telemetry import RapidTelemetry


class ScheduledQuery(BaseModel):
    query: str
    include_trace: bool = False
    llm_model: str | None = None
    execution_mode: Literal["retrieval_only", "full_rag"] = "full_rag"
    include_hyde: bool | None = None
    use_reranker: bool | None = None
    llm_num_predict: int | None = Field(default=None, ge=1, le=4096)
    hyde_num_predict: int | None = Field(default=None, ge=1, le=2048)
    scheduler_mode: Literal["round_robin", "least_conn", "rapid"] | None = None


config = load_config()
telemetry = RapidTelemetry(config)
catalog = ModelCatalog(config.ollama_url.rsplit("/api/generate", 1)[0] + "/api/tags")
app = FastAPI(title="RAPID-RAG Scheduler", version="0.2.0")
STATIC_DIR = Path(__file__).resolve().parents[1] / "static"
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


def _dump(model: BaseModel) -> dict[str, Any]:
    return model.model_dump() if hasattr(model, "model_dump") else model.dict()


def _profile(payload: ScheduledQuery) -> dict[str, Any]:
    values = _dump(payload)
    return {
        "model": values.get("llm_model") or config.llm_model,
        "execution_mode": values["execution_mode"],
        "include_hyde": config.use_hyde if values["include_hyde"] is None else values["include_hyde"],
        "use_reranker": config.use_reranker if values["use_reranker"] is None else values["use_reranker"],
        "bm25_candidates": config.bm25_candidates,
        "dense_top_k": config.search_top_k,
        "rerank_top_k": config.rerank_top_k,
        "llm_num_predict": values["llm_num_predict"] or config.llm_num_predict,
        "hyde_num_predict": values["hyde_num_predict"] or config.hyde_num_predict,
    }


@app.get("/", response_class=HTMLResponse)
@app.get("/gui", response_class=HTMLResponse)
def gui() -> HTMLResponse:
    return HTMLResponse((STATIC_DIR / "index.html").read_text(encoding="utf-8"))


@app.get("/scheduler/telemetry")
def scheduler_telemetry() -> dict[str, Any]:
    return {"mode": config.scheduler_mode, "replicas": telemetry.snapshot()}


@app.get("/scheduler/models")
def scheduler_models(refresh: bool = False) -> dict[str, Any]:
    installed, error = catalog.refresh(force=refresh)
    return {
        "installed_models": installed,
        "configured_models": config.llm_model_options,
        "default_model": config.llm_model,
        "discovery_error": error,
    }


@app.post("/query")
def query(payload: ScheduledQuery) -> dict[str, Any]:
    selected_model = payload.llm_model or config.llm_model
    valid, error = catalog.validate(selected_model)
    if not valid:
        raise HTTPException(status_code=422, detail=error)
    decision = telemetry.choose(_profile(payload), mode=payload.scheduler_mode)
    backend = decision["selected_backend"]
    forwarded = _dump(payload)
    forwarded.pop("scheduler_mode", None)
    # The ingress needs timings for telemetry even when the caller does not
    # request a trace; the trace is removed again before returning.
    forwarded["include_trace"] = True
    try:
        response = requests.post(
            f"{config.scheduler_backends[backend].rstrip('/')}/query",
            json=forwarded,
            timeout=620,
        )
        response.raise_for_status()
        result = response.json()
    except (requests.RequestException, ValueError) as exc:
        telemetry.record_completion(backend, _profile(payload), None)
        raise HTTPException(status_code=502, detail=f"scheduled backend {backend} failed: {exc}") from exc
    trace = result.setdefault("trace", {})
    trace["route"] = {
        "external_backend": backend,
        "internal_worker": (trace.get("route") or {}).get("internal_worker"),
    }
    trace["scheduler"] = decision
    telemetry.record_completion(backend, trace.get("request_profile") or _profile(payload), trace.get("timings_ms"))
    if not payload.include_trace:
        result.pop("trace", None)
    return result


@app.api_route("/{path:path}", methods=["GET", "POST"])
async def proxy_admin(path: str, request: Request) -> Response:
    """Keep existing health/admin/internal-stress routes reachable through ingress."""
    target = f"{config.scheduler_backends['api-a'].rstrip('/')}/{path}"
    try:
        response = requests.request(
            request.method,
            target,
            params=dict(request.query_params),
            content=await request.body(),
            headers={"content-type": request.headers.get("content-type", "application/json")},
            timeout=30,
        )
        return Response(content=response.content, status_code=response.status_code, media_type=response.headers.get("content-type"))
    except requests.RequestException as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
