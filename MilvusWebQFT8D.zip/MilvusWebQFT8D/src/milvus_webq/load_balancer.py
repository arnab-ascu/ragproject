from __future__ import annotations

import itertools
import threading
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from typing import Callable, TypeVar

from .config import RuntimeConfig

T = TypeVar("T")


@dataclass
class RouteTrace:
    external_backend: str
    internal_worker: str


class ExternalLoadBalancer:
    """App-level stand-in for Nginx/Traefik round-robin routing."""

    def __init__(self, config: RuntimeConfig):
        self.backends = config.external_backends or [config.active_backend]
        self._cycle = itertools.cycle(self.backends)
        self._lock = threading.Lock()

    def choose_backend(self) -> str:
        with self._lock:
            return next(self._cycle)


class InternalThreadPool:
    def __init__(self, max_workers: int):
        self.executor = ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="rag-worker")

    def run(self, fn: Callable[[], T]) -> tuple[T, str]:
        def wrapped() -> tuple[T, str]:
            return fn(), threading.current_thread().name

        return self.executor.submit(wrapped).result()
