# Infrastructure Notes

## Vector database placement

The project should use Docker Milvus as the vector database. End users should
not receive a local `.db` file or raw embedding storage. The Python app connects
to Milvus through `MILVUS_URI`, normally `http://localhost:19530` on a laptop or
`http://<lan-host>:19530` on a trusted LAN.

## Fresh Milvus container

This repository includes a fresh `docker-compose.yml` with separate named
volumes:

- `mwq_milvus`
- `mwq_etcd`
- `mwq_minio`

Stop the older containers if they already use port `19530`, then run:

```powershell
docker compose up -d
```

For LAN-only deployment, bind to `0.0.0.0` and restrict access using corporate
firewall/VPN rules. For laptop-only testing, set `MILVUS_BIND_HOST=127.0.0.1`.

## External load balancing

The concrete deployable option is `infra/nginx-load-balancer.conf`. It sends
traffic from port `8080` to two API instances on ports `8000` and `8001`.

The Python service also records a visible route trace with an
`external_backend` and `internal_worker`. This is useful for demos on one
machine where only one API process is actually running.
