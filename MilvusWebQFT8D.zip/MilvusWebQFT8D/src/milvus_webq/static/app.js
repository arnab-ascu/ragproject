const state = {
  config: null,
};

const $ = (id) => document.getElementById(id);

function setBusy(button, busy, label) {
  button.disabled = busy;
  button.textContent = busy ? "Working..." : label;
}

async function requestJson(url, options = {}) {
  const response = await fetch(url, options);
  const text = await response.text();
  let payload;
  try {
    payload = text ? JSON.parse(text) : {};
  } catch {
    payload = { raw: text };
  }
  if (!response.ok) {
    throw new Error(payload.detail || payload.raw || response.statusText);
  }
  return payload;
}

function pretty(value) {
  return JSON.stringify(value, null, 2);
}

function renderSources(sources) {
  if (!sources || !sources.length) {
    $("sourcesOutput").className = "source-list empty";
    $("sourcesOutput").textContent = "No sources returned.";
    return;
  }
  $("sourcesOutput").className = "source-list";
  $("sourcesOutput").innerHTML = sources
    .map((source, index) => {
      const score = source.score == null ? "n/a" : Number(source.score).toFixed(4);
      const rerank = source.rerank_score == null ? "n/a" : Number(source.rerank_score).toFixed(4);
      return `
        <article class="source">
          <strong>${index + 1}. ${escapeHtml(source.title || "Untitled")}</strong>
          <span>ID: ${escapeHtml(source.doc_id || "unknown")}</span>
          <span>Vector: ${score} | Rerank: ${rerank}</span>
        </article>
      `;
    })
    .join("");
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

async function refreshHealth() {
  try {
    const health = await requestJson("/health");
    $("healthDot").className = "dot ok";
    $("healthText").textContent = `${health.rows} rows | ${health.config.llm_model}`;
  } catch (error) {
    $("healthDot").className = "dot bad";
    $("healthText").textContent = error.message;
  }
}

async function askQuestion() {
  const button = $("askButton");
  setBusy(button, true, "Ask");
  const executionMode = $("executionMode").value;
  $("answerOutput").textContent = executionMode === "retrieval_only"
    ? "Running retrieval-only pipeline..."
    : "Running HyDE, retrieval, reranking, and generation...";
  $("answerOutput").className = "output";
  try {
    const payload = await requestJson("/query", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        query: $("queryText").value.trim(),
        include_trace: $("includeTrace").checked,
        llm_model: $("userLlmModel") ? $("userLlmModel").value : null,
        execution_mode: executionMode,
        include_hyde: $("requestHyde").checked,
        llm_num_predict: Number($("requestLlmNumPredict").value),
        hyde_num_predict: Number($("requestHydeNumPredict").value),
        scheduler_mode: $("schedulerMode").value || null,
      }),
    });
    $("answerOutput").textContent = payload.answer || "No answer returned.";
    renderSources(payload.sources);
    $("traceOutput").textContent = payload.trace ? pretty(payload.trace) : "Trace disabled.";
    $("traceOutput").className = "output";
  } catch (error) {
    $("answerOutput").textContent = `Request failed: ${error.message}`;
  } finally {
    setBusy(button, false, "Ask");
  }
}

function fillSelect(select, options, value) {
  if (!select) return;
  select.innerHTML = "";
  for (const option of options || [value]) {
    const node = document.createElement("option");
    node.value = option;
    node.textContent = option;
    select.appendChild(node);
  }
  select.value = value;
}

async function refreshConfig() {
  const config = await requestJson("/admin/config");
  state.config = config;
  fillSelect($("userLlmModel"), config.llm_model_options, config.llm_model);
  fillSelect($("llmModel"), config.llm_model_options, config.llm_model);
  fillSelect($("embeddingModel"), config.embedding_model_options, config.embedding_model);
  $("finalTopK").value = config.final_top_k;
  $("bm25Candidates").value = config.bm25_candidates;
  $("rerankTopK").value = config.rerank_top_k;
  $("maxSourceChars").value = config.max_source_chars;
  $("llmNumPredict").value = config.llm_num_predict;
  $("hydeNumPredict").value = config.hyde_num_predict;
  $("requestLlmNumPredict").value = config.llm_num_predict;
  $("requestHydeNumPredict").value = config.hyde_num_predict;
  $("requestHyde").checked = config.use_hyde;
  $("useHyde").checked = config.use_hyde;
  $("useReranker").checked = config.use_reranker;
  $("configOutput").textContent = pretty(config);
}

async function refreshInstalledModels() {
  try {
    const catalog = await requestJson("/scheduler/models");
    if (Array.isArray(catalog.installed_models)) {
      const selected = catalog.installed_models.includes(state.config.llm_model)
        ? state.config.llm_model
        : catalog.installed_models[0];
      fillSelect($("userLlmModel"), catalog.installed_models, selected);
      fillSelect($("llmModel"), catalog.installed_models, selected);
      if (!catalog.installed_models.length) {
        $("configOutput").textContent = "No Ollama models are installed. Pull a model before full-RAG tests.";
      }
    }
  } catch (error) {
    // Direct API development mode may not expose the scheduler endpoint.
    console.warn("Installed-model discovery unavailable:", error.message);
  }
}

async function saveConfig() {
  const button = $("saveConfigButton");
  setBusy(button, true, "Apply Settings");
  try {
    const values = {
      llm_model: $("llmModel").value,
      embedding_model: $("embeddingModel").value,
      final_top_k: Number($("finalTopK").value),
      bm25_candidates: Number($("bm25Candidates").value),
      rerank_top_k: Number($("rerankTopK").value),
      max_source_chars: Number($("maxSourceChars").value),
      llm_num_predict: Number($("llmNumPredict").value),
      hyde_num_predict: Number($("hydeNumPredict").value),
      use_hyde: $("useHyde").checked,
      use_reranker: $("useReranker").checked,
    };
    const updated = await requestJson("/admin/config", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        values,
        persist: $("persistConfig").checked,
        reload_service: true,
      }),
    });
    $("configOutput").textContent = pretty(updated);
  } catch (error) {
    $("configOutput").textContent = `Update failed: ${error.message}`;
  } finally {
    setBusy(button, false, "Apply Settings");
  }
}

async function refreshAdaptiveStatus() {
  try {
    const adaptive = await requestJson("/admin/adaptive");
    if ($("adaptiveStateText")) $("adaptiveStateText").textContent = adaptive.current_state || "NORMAL";
    if ($("loadIndexVal")) $("loadIndexVal").textContent = Number(adaptive.load_index || 0).toFixed(2);
    if ($("adaptiveBudgetToggle")) $("adaptiveBudgetToggle").checked = Boolean(adaptive.enabled);
    if ($("adaptiveSnapshotOutput")) $("adaptiveSnapshotOutput").textContent = pretty(adaptive);

    const badge = $("adaptiveBadge");
    if (badge) {
      if (adaptive.current_state === "SATURATED") {
        badge.style.background = "#991b1b";
        badge.style.color = "#fca5a5";
        badge.style.border = "1px solid #ef4444";
      } else if (adaptive.current_state === "BUSY") {
        badge.style.background = "#854d0e";
        badge.style.color = "#fef08a";
        badge.style.border = "1px solid #eab308";
      } else {
        badge.style.background = "#166534";
        badge.style.color = "#4ade80";
        badge.style.border = "1px solid #22c55e";
      }
    }
  } catch (error) {
    console.warn("Adaptive status unavailable:", error.message);
  }
}

async function toggleAdaptive() {
  try {
    const enabled = $("adaptiveBudgetToggle").checked;
    await requestJson("/admin/adaptive/toggle", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ enabled }),
    });
    await refreshAdaptiveStatus();
  } catch (error) {
    alert(`Failed to toggle adaptive controller: ${error.message}`);
  }
}

async function exportExperimentConfig() {
  const button = $("exportConfigButton");
  setBusy(button, true, "Export Experiment Config");
  try {
    const result = await requestJson("/admin/export-config", { method: "POST" });
    $("configOutput").textContent = `[SUCCESS] Exported experiment config to:\n${result.filepath}\n\n${pretty(result.bundle)}`;
  } catch (error) {
    $("configOutput").textContent = `Export failed: ${error.message}`;
  } finally {
    setBusy(button, false, "Export Experiment Config");
  }
}

async function runStress() {
  const button = $("runStressButton");
  setBusy(button, true, "Run Stress Test");
  $("stressOutput").className = "output";
  $("stressOutput").textContent = "Running stress test...";
  const queries = $("stressQueries").value
    .split("\n")
    .map((line) => line.trim())
    .filter(Boolean);
  try {
    const payload = await requestJson("/stress", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        queries,
        concurrency: Number($("stressConcurrency").value),
        total_requests: Number($("stressRequests").value),
        include_generation: $("stressGeneration").checked,
        include_hyde: $("stressHyde").checked,
      }),
    });
    $("stressOutput").textContent = pretty(payload);
  } catch (error) {
    $("stressOutput").textContent = `Stress test failed: ${error.message}`;
  } finally {
    setBusy(button, false, "Run Stress Test");
  }
}

function setupTabs() {
  document.querySelectorAll(".tab").forEach((tab) => {
    tab.addEventListener("click", () => {
      document.querySelectorAll(".tab").forEach((item) => item.classList.remove("active"));
      document.querySelectorAll(".view").forEach((item) => item.classList.remove("active"));
      tab.classList.add("active");
      $(tab.dataset.view).classList.add("active");
    });
  });
}

window.addEventListener("DOMContentLoaded", async () => {
  setupTabs();
  $("askButton").addEventListener("click", askQuestion);
  $("refreshConfigButton").addEventListener("click", async () => {
    await refreshConfig();
    await refreshAdaptiveStatus();
  });
  $("saveConfigButton").addEventListener("click", saveConfig);
  $("runStressButton").addEventListener("click", runStress);
  if ($("exportConfigButton")) $("exportConfigButton").addEventListener("click", exportExperimentConfig);
  if ($("adaptiveBudgetToggle")) $("adaptiveBudgetToggle").addEventListener("change", toggleAdaptive);

  await refreshHealth();
  await refreshConfig();
  await refreshInstalledModels();
  await refreshAdaptiveStatus();

  setInterval(async () => {
    await refreshHealth();
    await refreshAdaptiveStatus();
  }, 5000);
});
