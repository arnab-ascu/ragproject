# Results

Smoke verification from this modularization pass:

- Docker Milvus was reachable on `http://localhost:19530`.
- New limited collection was created:
  `internship_rag_scidocs_1000_all_mpnet_base_v2_768`.
- Collection row count after ingestion: `1000`.
- Retrieval stress smoke test passed with zero errors.
- End-to-end query path returned an answer, sources, HyDE text, route trace,
  stage timings, and internal worker name.

For formal reporting, save API `/stress` responses here as timestamped JSON.
