from __future__ import annotations

import enum
import threading
import time
from dataclasses import dataclass, field
from typing import Any

from .config import RuntimeConfig


class AdaptiveState(str, enum.Enum):
    NORMAL = "NORMAL"
    BUSY = "BUSY"
    SATURATED = "SATURATED"


PROFILES: dict[AdaptiveState, dict[str, Any]] = {
    AdaptiveState.NORMAL: {
        "use_hyde": True,
        "use_reranker": True,
        "bm25_candidates": 150,
        "search_top_k": 30,
        "rerank_top_k": 3,
        "llm_num_predict": 220,
        "hyde_num_predict": 120,
    },
    AdaptiveState.BUSY: {
        "use_hyde": True,
        "use_reranker": True,
        "bm25_candidates": 100,
        "search_top_k": 20,
        "rerank_top_k": 3,
        "llm_num_predict": 128,
        "hyde_num_predict": 64,
    },
    AdaptiveState.SATURATED: {
        "use_hyde": False,
        "use_reranker": True,
        "bm25_candidates": 50,
        "search_top_k": 10,
        "rerank_top_k": 2,
        "llm_num_predict": 64,
        "hyde_num_predict": 32,
    },
}


class AdaptiveBudgetController:
    """Manages load-adaptive RAG budgets using hysteresis to prevent state oscillation."""

    def __init__(self, config: RuntimeConfig):
        self.config = config
        self.state = AdaptiveState.NORMAL
        self.active_requests = 0
        self._lock = threading.RLock()
        self._recent_latencies: list[float] = []
        self._history: list[dict[str, Any]] = []

    def record_start(self) -> int:
        with self._lock:
            self.active_requests += 1
            return self.active_requests

    def record_finish(self, total_ms: float) -> None:
        with self._lock:
            self.active_requests = max(0, self.active_requests - 1)
            self._recent_latencies.append(total_ms)
            if len(self._recent_latencies) > 20:
                self._recent_latencies.pop(0)

    def compute_load_index(self) -> float:
        with self._lock:
            capacity = max(1, self.config.max_workers)
            active_ratio = self.active_requests / capacity
            mean_latency = (
                sum(self._recent_latencies) / len(self._recent_latencies)
                if self._recent_latencies
                else 0.0
            )
            slo_target = max(1.0, self.config.slo_target_ms)
            latency_ratio = min(1.0, mean_latency / slo_target)
            return round(active_ratio + 0.3 * latency_ratio, 4)

    def evaluate(self, active_count: int | None = None) -> tuple[AdaptiveState, float, dict[str, Any]]:
        with self._lock:
            current_active = active_count if active_count is not None else self.active_requests
            capacity = max(1, self.config.max_workers)
            active_ratio = current_active / capacity
            mean_latency = (
                sum(self._recent_latencies) / len(self._recent_latencies)
                if self._recent_latencies
                else 0.0
            )
            slo_target = max(1.0, self.config.slo_target_ms)
            latency_ratio = min(1.0, mean_latency / slo_target)
            load_index = round(active_ratio + 0.3 * latency_ratio, 4)

            old_state = self.state
            if self.state == AdaptiveState.NORMAL:
                if load_index >= self.config.load_busy_enter:
                    self.state = AdaptiveState.BUSY
            elif self.state == AdaptiveState.BUSY:
                if load_index >= self.config.load_saturated_enter:
                    self.state = AdaptiveState.SATURATED
                elif load_index < self.config.load_busy_exit:
                    self.state = AdaptiveState.NORMAL
            elif self.state == AdaptiveState.SATURATED:
                if load_index < self.config.load_saturated_exit:
                    if load_index < self.config.load_busy_exit:
                        self.state = AdaptiveState.NORMAL
                    else:
                        self.state = AdaptiveState.BUSY

            if self.state != old_state:
                entry = {
                    "timestamp": time.time(),
                    "from_state": old_state.value,
                    "to_state": self.state.value,
                    "load_index": load_index,
                    "active_requests": current_active,
                }
                self._history.append(entry)
                if len(self._history) > 50:
                    self._history.pop(0)

            budget_params = dict(PROFILES[self.state])
            return self.state, load_index, budget_params

    def get_effective_params(
        self,
        request_include_hyde: bool | None = None,
        request_use_reranker: bool | None = None,
        request_llm_num_predict: int | None = None,
        request_hyde_num_predict: int | None = None,
    ) -> tuple[AdaptiveState, float, dict[str, Any]]:
        if not self.config.adaptive_budget:
            effective = {
                "use_hyde": self.config.use_hyde if request_include_hyde is None else request_include_hyde,
                "use_reranker": self.config.use_reranker if request_use_reranker is None else request_use_reranker,
                "bm25_candidates": self.config.bm25_candidates,
                "search_top_k": self.config.search_top_k,
                "rerank_top_k": self.config.rerank_top_k,
                "llm_num_predict": request_llm_num_predict or self.config.llm_num_predict,
                "hyde_num_predict": request_hyde_num_predict or self.config.hyde_num_predict,
            }
            return AdaptiveState.NORMAL, 0.0, effective

        state, load_index, defaults = self.evaluate()
        effective = {
            "use_hyde": defaults["use_hyde"] if request_include_hyde is None else request_include_hyde,
            "use_reranker": defaults["use_reranker"] if request_use_reranker is None else request_use_reranker,
            "bm25_candidates": defaults["bm25_candidates"],
            "search_top_k": defaults["search_top_k"],
            "rerank_top_k": defaults["rerank_top_k"],
            "llm_num_predict": request_llm_num_predict or defaults["llm_num_predict"],
            "hyde_num_predict": request_hyde_num_predict or defaults["hyde_num_predict"],
        }
        return state, load_index, effective

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            return {
                "enabled": self.config.adaptive_budget,
                "current_state": self.state.value,
                "active_requests": self.active_requests,
                "load_index": self.compute_load_index(),
                "recent_mean_latency_ms": (
                    sum(self._recent_latencies) / len(self._recent_latencies)
                    if self._recent_latencies
                    else 0.0
                ),
                "thresholds": {
                    "load_normal_max": self.config.load_normal_max,
                    "load_busy_enter": self.config.load_busy_enter,
                    "load_busy_exit": self.config.load_busy_exit,
                    "load_saturated_enter": self.config.load_saturated_enter,
                    "load_saturated_exit": self.config.load_saturated_exit,
                },
                "transition_history": list(self._history),
            }
