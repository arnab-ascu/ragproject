#!/usr/bin/env python3
"""
RAPID-RAG Day 6: Main Experiment Matrix Execution Engine.

Evaluates routing policies (B0, B1, B2, B3) across workload classes (S, M, L, XL, MIX).
Logs detailed per-request timing traces, stage breakdowns, SLO compliance, adaptive state distribution,
and load balance metrics.

Outputs:
  - results/runs/<policy>_<workload>_<timestamp>/requests.csv
  - results/runs/<policy>_<workload>_<timestamp>/summary.json
  - results/runs/experiment_matrix_summary.csv
  - results/runs/experiment_matrix_summary.json
"""

import argparse
import csv
import json
import math
import random
import sys
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Tuple

PROJECT_ROOT = Path(__file__).resolve().parents[1]
RESULTS_DIR = PROJECT_ROOT / "results" / "runs"

DEFAULT_QUERIES = [
    "Impact of ambulance dispatch policies on emergency response times",
    "Machine learning applications in clinical decision support systems",
    "Optimization algorithms for supply chain management in healthcare",
    "Deep learning architectures for natural language processing",
    "Graph neural networks for drug discovery and molecular property prediction",
    "Reinforcement learning for autonomous navigation in robotics",
    "Transformer models for time series forecasting",
    "Evaluation metrics for retrieval-augmented generation systems",
    "Privacy-preserving federated learning in distributed edge networks",
    "Semantic vector search indexing techniques in high-dimensional spaces",
]

POLICIES = {
    "B0": {"name": "Round-Robin", "scheduler_mode": "round_robin", "adaptive_budget": False},
    "B1": {"name": "Least-Connections", "scheduler_mode": "least_conn", "adaptive_budget": False},
    "B2": {"name": "RAPID v0", "scheduler_mode": "rapid", "adaptive_budget": False},
    "B3": {"name": "RAPID + Adaptive", "scheduler_mode": "rapid", "adaptive_budget": True},
}

WORKLOAD_PROFILES = {
    "S": {"mode": "retrieval_only", "include_hyde": False, "llm_num_predict": 1, "hyde_num_predict": 1},
    "M": {"mode": "full_rag", "include_hyde": False, "llm_num_predict": 128, "hyde_num_predict": 64},
    "L": {"mode": "full_rag", "include_hyde": False, "llm_num_predict": 256, "hyde_num_predict": 64},
    "XL": {"mode": "full_rag", "include_hyde": True, "llm_num_predict": 512, "hyde_num_predict": 128},
}


def get_workload_params(workload_code: str) -> Dict[str, Any]:
    if workload_code in WORKLOAD_PROFILES:
        return dict(WORKLOAD_PROFILES[workload_code])
    if workload_code == "MIX":
        choice = random.choices(["S", "M", "L", "XL"], weights=[0.50, 0.30, 0.15, 0.05])[0]
        params = dict(WORKLOAD_PROFILES[choice])
        params["sub_type"] = choice
        return params
    raise ValueError(f"Unknown workload code: {workload_code}")


def toggle_adaptive_budget(base_url: str, enabled: bool) -> bool:
    targets = [
        "http://localhost:8080/admin/adaptive/toggle",
        "http://localhost:8000/admin/adaptive/toggle",
        f"{base_url.rstrip('/')}/admin/adaptive/toggle",
    ]
    for target in targets:
        try:
            req = urllib.request.Request(
                target,
                data=json.dumps({"enabled": enabled}).encode(),
                headers={"Content-Type": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode())
                return data.get("enabled", enabled)
        except Exception:
            continue
    print(f"[WARN] Failed to toggle adaptive budget via targets: {enabled}")
    return enabled


def percentile(data: List[float], pct: float) -> float:
    if not data:
        return 0.0
    sorted_data = sorted(data)
    k = (len(sorted_data) - 1) * (pct / 100.0)
    f = math.floor(k)
    c = math.ceil(k)
    if f == c:
        return sorted_data[int(k)]
    d0 = sorted_data[int(f)] * (c - k)
    d1 = sorted_data[int(c)] * (k - f)
    return round(d0 + d1, 2)


def execute_single_request(
    scheduler_url: str,
    query_text: str,
    policy_config: Dict[str, Any],
    workload_params: Dict[str, Any],
    llm_model: str,
    slo_target_ms: float,
    timeout_sec: float = 300.0,
) -> Dict[str, Any]:
    payload = {
        "query": query_text,
        "include_trace": True,
        "llm_model": llm_model,
        "execution_mode": workload_params["mode"],
        "include_hyde": workload_params["include_hyde"],
        "llm_num_predict": workload_params["llm_num_predict"],
        "hyde_num_predict": workload_params["hyde_num_predict"],
        "scheduler_mode": policy_config["scheduler_mode"],
    }
    
    start_time = time.perf_counter()
    status_code = 500
    error_msg = None
    res_json = {}
    
    try:
        req = urllib.request.Request(
            f"{scheduler_url.rstrip('/')}/query",
            data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=timeout_sec) as resp:
            status_code = resp.status
            res_json = json.loads(resp.read().decode())
    except Exception as exc:
        status_code = 500
        error_msg = str(exc)
        
    elapsed_ms = round((time.perf_counter() - start_time) * 1000, 2)
    trace = res_json.get("trace", {})
    timings = trace.get("timings_ms", {})
    route = trace.get("route", {})
    adaptive = trace.get("adaptive", {})
    
    assigned_backend = (
        route.get("external_backend")
        or (trace.get("scheduler") or {}).get("selected_backend")
        or "unknown"
    )
    
    adaptive_state = adaptive.get("profile") or "NORMAL"
    load_index = adaptive.get("load_index", 0.0)
    
    return {
        "status_code": status_code,
        "total_ms": elapsed_ms,
        "hyde_ms": round(timings.get("hyde", 0.0), 2),
        "retrieval_ms": round(timings.get("retrieval", 0.0), 2),
        "generation_ms": round(timings.get("generation", 0.0), 2),
        "assigned_backend": assigned_backend,
        "adaptive_state": adaptive_state,
        "load_index": load_index,
        "slo_violation": elapsed_ms > slo_target_ms or status_code != 200,
        "error": error_msg,
    }


def run_experiment_cell(
    policy_code: str,
    workload_code: str,
    scheduler_url: str,
    concurrency: int,
    total_requests: int,
    llm_model: str,
    slo_target_ms: float,
    output_dir: Path,
) -> Dict[str, Any]:
    policy_config = POLICIES[policy_code]
    print(f"\n================================================================================")
    print(f"RUNNING CELL: Policy={policy_code} ({policy_config['name']}) | Workload={workload_code}")
    print(f"Concurrency={concurrency} | Total Requests={total_requests} | LLM={llm_model}")
    print(f"================================================================================")
    
    # Toggle adaptive budget setting for this run
    toggle_adaptive_budget(scheduler_url, policy_config["adaptive_budget"])
    
    cell_start_time = time.perf_counter()
    records: List[Dict[str, Any]] = []
    
    def worker(req_idx: int) -> Dict[str, Any]:
        query_text = DEFAULT_QUERIES[req_idx % len(DEFAULT_QUERIES)]
        params = get_workload_params(workload_code)
        rec = execute_single_request(
            scheduler_url,
            query_text,
            policy_config,
            params,
            llm_model,
            slo_target_ms,
        )
        rec["request_id"] = req_idx
        rec["workload_type"] = params.get("sub_type", workload_code)
        return rec

    with ThreadPoolExecutor(max_workers=concurrency) as executor:
        futures = [executor.submit(worker, i) for i in range(total_requests)]
        for fut in as_completed(futures):
            records.append(fut.result())
            
    wall_clock_sec = round(time.perf_counter() - cell_start_time, 3)
    records.sort(key=lambda r: r["request_id"])
    
    # Aggregations
    succ = [r for r in records if r["status_code"] == 200]
    failed = [r for r in records if r["status_code"] != 200]
    latencies = [r["total_ms"] for r in succ]
    hyde_times = [r["hyde_ms"] for r in succ if r["hyde_ms"] > 0]
    retrieval_times = [r["retrieval_ms"] for r in succ]
    generation_times = [r["generation_ms"] for r in succ if r["generation_ms"] > 0]
    
    slo_violations = sum(1 for r in records if r["slo_violation"])
    qps = round(len(records) / wall_clock_sec, 2) if wall_clock_sec > 0 else 0.0
    
    # Backend load split & imbalance ratio
    backend_counts: Dict[str, int] = {}
    for r in records:
        b = r["assigned_backend"]
        backend_counts[b] = backend_counts.get(b, 0) + 1
        
    counts_list = list(backend_counts.values())
    max_count = max(counts_list) if counts_list else 0
    min_count = min(counts_list) if counts_list else 0
    imbalance_ratio = round(max_count / max(1, min_count), 2)
    
    # Adaptive state breakdown
    state_counts: Dict[str, int] = {}
    for r in records:
        st = r["adaptive_state"]
        state_counts[st] = state_counts.get(st, 0) + 1
        
    summary = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "policy": policy_code,
        "policy_name": policy_config["name"],
        "workload": workload_code,
        "concurrency": concurrency,
        "total_requests": len(records),
        "successful_requests": len(succ),
        "failed_requests": len(failed),
        "wall_clock_sec": wall_clock_sec,
        "qps": qps,
        "latency_mean_ms": round(sum(latencies) / max(1, len(latencies)), 2),
        "latency_min_ms": min(latencies) if latencies else 0.0,
        "latency_max_ms": max(latencies) if latencies else 0.0,
        "latency_p50_ms": percentile(latencies, 50),
        "latency_p95_ms": percentile(latencies, 95),
        "latency_p99_ms": percentile(latencies, 99),
        "stage_hyde_mean_ms": round(sum(hyde_times) / max(1, len(hyde_times)), 2),
        "stage_retrieval_mean_ms": round(sum(retrieval_times) / max(1, len(retrieval_times)), 2),
        "stage_generation_mean_ms": round(sum(generation_times) / max(1, len(generation_times)), 2),
        "slo_target_ms": slo_target_ms,
        "slo_violations": slo_violations,
        "slo_compliance_pct": round((1.0 - (slo_violations / max(1, len(records)))) * 100, 2),
        "backend_distribution": backend_counts,
        "imbalance_ratio": imbalance_ratio,
        "adaptive_state_distribution": state_counts,
    }
    
    # Save output files
    timestamp_str = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")
    run_dir = output_dir / f"{policy_code}_{workload_code}_{timestamp_str}"
    run_dir.mkdir(parents=True, exist_ok=True)
    
    # Write summary.json
    (run_dir / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    
    # Write requests.csv
    csv_fields = [
        "request_id", "workload_type", "status_code", "total_ms",
        "hyde_ms", "retrieval_ms", "generation_ms", "assigned_backend",
        "adaptive_state", "load_index", "slo_violation", "error"
    ]
    with (run_dir / "requests.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=csv_fields)
        writer.writeheader()
        writer.writerows(records)
        
    print(f"Cell Completed: P50={summary['latency_p50_ms']}ms | P95={summary['latency_p95_ms']}ms | QPS={summary['qps']} | SLO={summary['slo_compliance_pct']}%")
    print(f"Saved run artifacts to: {run_dir}")
    return summary


def run_full_matrix(
    policies: List[str],
    workloads: List[str],
    scheduler_url: str,
    concurrency: int,
    requests_per_cell: int,
    llm_model: str,
    slo_target_ms: float,
    output_dir: Path,
) -> List[Dict[str, Any]]:
    matrix_results: List[Dict[str, Any]] = []
    
    for pol in policies:
        for wk in workloads:
            res = run_experiment_cell(
                pol,
                wk,
                scheduler_url,
                concurrency,
                requests_per_cell,
                llm_model,
                slo_target_ms,
                output_dir,
            )
            matrix_results.append(res)
            time.sleep(1.0) # cool down between cells
            
    # Write master summary files
    output_dir.mkdir(parents=True, exist_ok=True)
    master_json = output_dir / "experiment_matrix_summary.json"
    master_csv = output_dir / "experiment_matrix_summary.csv"
    
    master_json.write_text(json.dumps(matrix_results, indent=2) + "\n", encoding="utf-8")
    
    if matrix_results:
        csv_keys = [
            "policy", "policy_name", "workload", "concurrency", "total_requests",
            "successful_requests", "qps", "latency_p50_ms", "latency_p95_ms", "latency_p99_ms",
            "latency_mean_ms", "stage_hyde_mean_ms", "stage_retrieval_mean_ms", "stage_generation_mean_ms",
            "slo_compliance_pct", "imbalance_ratio"
        ]
        with master_csv.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=csv_keys, extrasaction="ignore")
            writer.writeheader()
            writer.writerows(matrix_results)
            
    # Display Markdown Table
    print("\n\n" + "=" * 100)
    print("DAY 6: EXPERIMENT MATRIX BENCHMARK SUMMARY")
    print("=" * 100)
    print(f"| {'Policy':<6} | {'Workload':<8} | {'QPS':<6} | {'P50 (ms)':<9} | {'P95 (ms)':<9} | {'P99 (ms)':<9} | {'SLO %':<7} | {'Imbalance':<9} |")
    print(f"|{'-'*8}|{'-'*10}|{'-'*8}|{'-'*11}|{'-'*11}|{'-'*11}|{'-'*9}|{'-'*11}|")
    for r in matrix_results:
        print(
            f"| {r['policy']:<6} | {r['workload']:<8} | {r['qps']:<6.2f} | {r['latency_p50_ms']:<9.1f} | "
            f"{r['latency_p95_ms']:<9.1f} | {r['latency_p99_ms']:<9.1f} | {r['slo_compliance_pct']:<7.1f} | "
            f"{r['imbalance_ratio']:<9.2f} |"
        )
    print("=" * 100)
    print(f"Master Summary CSV: {master_csv}")
    print(f"Master Summary JSON: {master_json}\n")
    return matrix_results


def main():
    parser = argparse.ArgumentParser(description="RAPID-RAG Day 6 Experiment Matrix Runner")
    parser.add_argument("--policies", nargs="+", default=["B0", "B1", "B2", "B3"], choices=["B0", "B1", "B2", "B3"])
    parser.add_argument("--workloads", nargs="+", default=["S", "M", "L", "XL", "MIX"], choices=["S", "M", "L", "XL", "MIX"])
    parser.add_argument("--url", default="http://localhost:8002", help="Scheduler ingress URL (default: http://localhost:8002)")
    parser.add_argument("--concurrency", type=int, default=4, help="Concurrency level per cell (default: 4)")
    parser.add_argument("--requests", type=int, default=12, help="Number of requests per matrix cell (default: 12)")
    parser.add_argument("--llm", default="mistral:latest", help="LLM model tag to evaluate (default: mistral:latest)")
    parser.add_argument("--slo", type=float, default=60000.0, help="SLO target latency in ms (default: 60000.0)")
    parser.add_argument("--output-dir", default=str(RESULTS_DIR), help="Directory to save experiment output")
    args = parser.parse_args()

    run_full_matrix(
        policies=args.policies,
        workloads=args.workloads,
        scheduler_url=args.url,
        concurrency=args.concurrency,
        requests_per_cell=args.requests,
        llm_model=args.llm,
        slo_target_ms=args.slo,
        output_dir=Path(args.output_dir),
    )


if __name__ == "__main__":
    main()
