from __future__ import annotations

import json
import re
import time
from typing import TYPE_CHECKING
from typing import Any

from pymilvus import DataType, MilvusClient

from .config import RuntimeConfig

if TYPE_CHECKING:
    from .data import CorpusBundle
    from .models import EmbeddingModel


def model_slug(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", value.lower()).strip("_")


def collection_name(config: RuntimeConfig, embedding_dim: int) -> str:
    dataset = model_slug(config.dataset_name)
    model = model_slug(config.embedding_model.split("/")[-1])[-40:]
    return f"{config.collection_prefix}_{dataset}_{config.document_limit}_{model}_{embedding_dim}"[:255]


class MilvusStore:
    def __init__(self, config: RuntimeConfig, embedder: EmbeddingModel):
        self.config = config
        self.embedder = embedder
        self.name = collection_name(config, embedder.dim)
        kwargs: dict[str, Any] = {"uri": config.milvus_uri, "timeout": 10}
        if config.milvus_token:
            kwargs["token"] = config.milvus_token
        self.client = MilvusClient(**kwargs)
        self.client.list_collections()

    def setup(self, rebuild: bool = False) -> None:
        exists = self.client.has_collection(self.name)
        if exists and rebuild:
            self.client.drop_collection(self.name)
            exists = False
        if not exists:
            schema = self.client.create_schema(auto_id=False, enable_dynamic_field=False)
            schema.add_field("doc_id", DataType.VARCHAR, is_primary=True, max_length=256)
            schema.add_field("embedding", DataType.FLOAT_VECTOR, dim=self.embedder.dim)
            schema.add_field("title", DataType.VARCHAR, max_length=8192)
            schema.add_field("text", DataType.VARCHAR, max_length=65535)
            index_params = self.client.prepare_index_params()
            index_params.add_index(
                field_name="embedding",
                index_type=self.config.index_type,
                metric_type=self.config.metric_type,
                params={"nlist": self.config.nlist},
            )
            self.client.create_collection(self.name, schema=schema, index_params=index_params)
        self.client.load_collection(self.name)

    def row_count(self) -> int:
        stats = self.client.get_collection_stats(self.name)
        return int(stats.get("row_count", 0))

    def ingest(self, bundle: CorpusBundle, rebuild: bool = False) -> dict[str, float]:
        self.setup(rebuild=rebuild)
        existing = self.row_count()
        expected = len(bundle.corpus_ids)
        if existing == expected:
            return {"documents": existing, "seconds": 0.0, "docs_per_second": 0.0}
        if existing:
            raise RuntimeError(
                f"Collection {self.name} has {existing} rows but expected {expected}. "
                "Use --rebuild for a clean subset collection."
            )

        started = time.perf_counter()
        inserted = 0
        for start in range(0, expected, self.config.insert_batch_size):
            end = min(start + self.config.insert_batch_size, expected)
            batch_ids = bundle.corpus_ids[start:end]
            texts = [bundle.corpus_texts[i] for i in range(start, end)]
            vectors = self.embedder.encode(texts)
            rows = []
            for offset, doc_id in enumerate(batch_ids):
                doc = bundle.corpus[doc_id]
                rows.append(
                    {
                        "doc_id": str(doc_id)[:256],
                        "embedding": vectors[offset],
                        "title": (doc.get("title") or "")[:8192],
                        "text": (doc.get("text") or "")[:65535],
                    }
                )
            result = self.client.insert(self.name, rows)
            inserted += int(result.get("insert_count", len(rows)))
        self.client.flush(self.name)
        self.client.load_collection(self.name)
        seconds = time.perf_counter() - started
        return {"documents": inserted, "seconds": seconds, "docs_per_second": inserted / seconds}

    def search_vector(
        self,
        query_vector: list[float],
        top_k: int,
        candidate_ids: list[str] | None = None,
        output_fields: list[str] | None = None,
    ) -> list[dict]:
        filter_expr = ""
        if candidate_ids:
            quoted_ids = ", ".join(json.dumps(str(doc_id)) for doc_id in candidate_ids)
            filter_expr = f"doc_id in [{quoted_ids}]"
        hits = self.client.search(
            collection_name=self.name,
            data=[query_vector],
            anns_field="embedding",
            filter=filter_expr,
            limit=top_k,
            search_params={
                "metric_type": self.config.metric_type,
                "params": {"nprobe": self.config.nprobe},
            },
            output_fields=["title", "text"] if output_fields is None else output_fields,
        )[0]
        return [
            {
                "doc_id": str(hit["id"]),
                "score": float(hit["distance"]),
                **(hit.get("entity") or {}),
            }
            for hit in hits
        ]
