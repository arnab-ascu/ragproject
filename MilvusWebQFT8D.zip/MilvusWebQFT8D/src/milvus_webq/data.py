from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .config import PROJECT_ROOT, RuntimeConfig


@dataclass
class CorpusBundle:
    corpus: dict[str, dict[str, str]]
    queries: dict[str, str]
    qrels: dict[str, dict[str, int]]
    corpus_ids: list[str]
    query_ids: list[str]
    corpus_texts: list[str]


def document_text(doc: dict[str, Any]) -> str:
    title = (doc.get("title") or "").strip()
    text = (doc.get("text") or "").strip()
    return f"{title}\n\n{text}".strip()


def load_beir_bundle(config: RuntimeConfig) -> CorpusBundle:
    dataset_path = PROJECT_ROOT / "data" / "beir" / config.dataset_name
    required = [
        dataset_path / "corpus.jsonl",
        dataset_path / "queries.jsonl",
        dataset_path / "qrels" / f"{config.dataset_split}.tsv",
    ]
    missing = [str(path) for path in required if not Path(path).is_file()]
    if missing:
        raise FileNotFoundError("Missing offline BEIR files:\n- " + "\n- ".join(missing))

    limited_corpus: dict[str, dict[str, str]] = {}
    with (dataset_path / "corpus.jsonl").open("r", encoding="utf-8") as handle:
        for line in handle:
            if config.document_limit and config.document_limit > 0 and len(limited_corpus) >= config.document_limit:
                break
            record = json.loads(line)
            doc_id = str(record["_id"])
            limited_corpus[doc_id] = {
                "title": record.get("title") or "",
                "text": record.get("text") or "",
            }

    queries: dict[str, str] = {}
    with (dataset_path / "queries.jsonl").open("r", encoding="utf-8") as handle:
        for line in handle:
            record = json.loads(line)
            queries[str(record["_id"])] = record.get("text") or ""

    qrels: dict[str, dict[str, int]] = {}
    with (dataset_path / "qrels" / f"{config.dataset_split}.tsv").open(
        "r",
        encoding="utf-8",
    ) as handle:
        next(handle, None)
        for line in handle:
            qid, doc_id, score = line.rstrip("\n").split("\t")
            qrels.setdefault(qid, {})[doc_id] = int(float(score))

    corpus_ids = list(limited_corpus)
    allowed = set(corpus_ids)
    limited_qrels = {
        qid: {doc_id: score for doc_id, score in rels.items() if doc_id in allowed}
        for qid, rels in qrels.items()
    }
    limited_qrels = {qid: rels for qid, rels in limited_qrels.items() if rels}
    query_ids = [qid for qid in limited_qrels if qid in queries]
    corpus_texts = [document_text(limited_corpus[doc_id]) for doc_id in corpus_ids]
    return CorpusBundle(limited_corpus, queries, limited_qrels, corpus_ids, query_ids, corpus_texts)
