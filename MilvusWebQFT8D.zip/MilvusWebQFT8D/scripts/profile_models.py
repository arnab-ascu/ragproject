"""Run one controlled query across installed Ollama models for Day-3 profiles."""

from __future__ import annotations

import argparse
import json
import statistics
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


ROOT = Path(__file__).resolve().parents[1]


def get_json(url: str, timeout: float = 15.0) -> dict:
    with urlopen(url, timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8"))


def post_json(url: str, body: dict, timeout: float) -> tuple[int, dict, str | None]:
    request = Request(url, data=json.dumps(body).encode("utf-8"), headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urlopen(request, timeout=timeout) as response:
            return response.status, json.loads(response.read().decode("utf-8")), None
    except HTTPError as exc:
        return exc.code, {}, exc.read().decode("utf-8", errors="replace")
    except (URLError, TimeoutError, json.JSONDecodeError) as exc:
        return 0, {}, str(exc)


def main() -> None:
    parser = argparse.ArgumentParser(description="Measure per-model RAPID-RAG latency profiles.")
    parser.add_argument("--url", default="http://localhost:8080/query")
    parser.add_argument("--query", default="Impact of ambulance dispatch policies")
    parser.add_argument("--models", help="Comma-separated installed model tags; defaults to scheduler discovery")
    parser.add_argument("--iterations", type=int, default=2)
    parser.add_argument("--execution-mode", choices=["retrieval_only", "full_rag"], default="full_rag")
    parser.add_argument("--hyde", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--llm-num-predict", type=int, default=64)
    parser.add_argument("--hyde-num-predict", type=int, default=32)
    parser.add_argument("--timeout", type=float, default=620)
    parser.add_argument("--output-dir", type=Path)
    args = parser.parse_args()
    if args.iterations < 1:
        raise SystemExit("--iterations must be positive")
    if args.models:
        models = [model.strip() for model in args.models.split(",") if model.strip()]
    else:
        try:
            catalog_url = args.url.rsplit("/query", 1)[0] + "/scheduler/models?refresh=true"
            catalog = get_json(catalog_url)
            models = catalog.get("installed_models") or []
        except Exception:
            models = ["llama3.2:1b", "llama3.2:latest", "mistral:latest"]
        if not models:
            models = ["llama3.2:1b", "llama3.2:latest", "mistral:latest"]
    output_dir = args.output_dir or ROOT / "results" / "model_profiles" / datetime.now().strftime("%Y%m%dT%H%M%S")
    output_dir.mkdir(parents=True, exist_ok=True)
    records = []
    for model in models:
        for iteration in range(args.iterations):
            payload = {
                "query": args.query,
                "include_trace": True,
                "llm_model": model,
                "execution_mode": args.execution_mode,
                "include_hyde": args.hyde,
                "llm_num_predict": args.llm_num_predict,
                "hyde_num_predict": args.hyde_num_predict,
            }
            started = time.perf_counter()
            status, response, error = post_json(args.url, payload, args.timeout)
            trace = response.get("trace") or {}
            records.append({
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "model": model,
                "iteration": iteration + 1,
                "status": status,
                "client_latency_ms": round((time.perf_counter() - started) * 1000, 3),
                "trace": trace,
                "error": error,
            })
    summary = {}
    for model in models:
        rows = [row for row in records if row["model"] == model and 200 <= row["status"] < 300]
        summary[model] = {
            "samples": len(rows),
            "mean_client_ms": statistics.mean(row["client_latency_ms"] for row in rows) if rows else None,
            "mean_server_ms": statistics.mean((row["trace"].get("total_ms") or 0) for row in rows) if rows else None,
            "mean_generation_ms": statistics.mean((row["trace"].get("timings_ms", {}).get("generation") or 0) for row in rows) if rows else None,
        }
    (output_dir / "model_profile_requests.jsonl").write_text("".join(json.dumps(row) + "\n" for row in records), encoding="utf-8")
    (output_dir / "model_profile_summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"output_dir": str(output_dir), "models": models, "summary": summary}, indent=2))


if __name__ == "__main__":
    main()
