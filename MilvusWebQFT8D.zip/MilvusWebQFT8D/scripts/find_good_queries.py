from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from milvus_webq.config import load_config
from milvus_webq.data import load_beir_bundle


def main() -> None:
    config = load_config()
    bundle = load_beir_bundle(config)

    ranked = []
    for qid in bundle.query_ids:
        rels = bundle.qrels[qid]
        best_score = max(rels.values())
        n_matches = len(rels)
        ranked.append((qid, bundle.queries[qid], best_score, n_matches))

    # Best relevance score first, then most matching relevant docs
    ranked.sort(key=lambda r: (-r[2], -r[3]))

    print(f"Corpus size (limited): {len(bundle.corpus_ids)}")
    print(f"Queries with at least one surviving relevant doc: {len(ranked)}\n")

    print(f"{'query_id':<10} {'score':<6} {'#docs':<6} query text")
    print("-" * 90)
    for qid, text, score, n in ranked[:20]:
        print(f"{qid:<10} {score:<6} {n:<6} {text}")


if __name__ == "__main__":
    main()