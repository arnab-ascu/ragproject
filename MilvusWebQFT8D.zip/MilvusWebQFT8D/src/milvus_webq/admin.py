from __future__ import annotations

from dataclasses import asdict
from typing import Any

from .config import RuntimeConfig, load_config, save_config


class AdminState:
    def __init__(self, config: RuntimeConfig | None = None):
        self.config = config or load_config()

    def view(self) -> dict[str, Any]:
        return asdict(self.config)

    def update(self, values: dict[str, Any], persist: bool = False) -> dict[str, Any]:
        for key, value in values.items():
            if not hasattr(self.config, key):
                raise KeyError(f"Unknown runtime setting: {key}")
            setattr(self.config, key, value)
        if persist:
            save_config(self.config)
        return self.view()
