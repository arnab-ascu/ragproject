import matplotlib.pyplot as plt
import numpy as np

# Evaluation Data (NDCG across all cutoffs)
metrics = ['NDCG@1', 'NDCG@3', 'NDCG@5', 'NDCG@10', 'NDCG@100']
dense_scores = [0.13043, 0.14257, 0.14246, 0.16798, 0.21562]
hybrid_scores = [0.13378, 0.14255, 0.14110, 0.16032, 0.17784]

x = np.arange(len(metrics))
width = 0.35

# Setup plot
fig, ax = plt.subplots(figsize=(10, 6))
rects1 = ax.bar(x - width/2, dense_scores, width, label='Dense-Only', color='#4C72B0')
rects2 = ax.bar(x + width/2, hybrid_scores, width, label='Hybrid (BM25+Dense+Rerank)', color='#55A868')

# Add labels, title, and formatting
ax.set_ylabel('NDCG Score')
ax.set_title('Figure 7.1: Dense-only vs. Hybrid Retrieval — NDCG Comparison')
ax.set_xticks(x)
ax.set_xticklabels(metrics)
ax.legend()
ax.grid(axis='y', linestyle='--', alpha=0.7)

# Add exact values on top of the bars
def autolabel(rects):
    for rect in rects:
        height = rect.get_height()
        ax.annotate(f'{height:.5f}',
                    xy=(rect.get_x() + rect.get_width() / 2, height),
                    xytext=(0, 3),  # 3 points vertical offset
                    textcoords="offset points",
                    ha='center', va='bottom', fontsize=9)

autolabel(rects1)
autolabel(rects2)

fig.tight_layout()

# Save the chart
plt.savefig('figure_7_1_ndcg_comparison.png', dpi=300)
print("Chart successfully saved as 'figure_7_1_ndcg_comparison.png'")