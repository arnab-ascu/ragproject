from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any


PROJECT_ROOT = Path(__file__).resolve().parents[2]


@dataclass
class RuntimeConfig:
    dataset_name: str = "scidocs"
    dataset_split: str = "test"
    document_limit: int = 25657
    milvus_uri: str = "http://localhost:19530"
    milvus_token: str | None = None
    collection_prefix: str = "internship_rag"
    embedding_model: str = "sentence-transformers/all-mpnet-base-v2"
    embedding_dim: int = 768
    embedding_model_options: list[str] = field(
        default_factory=lambda: [
            "sentence-transformers/all-mpnet-base-v2",
            "sentence-transformers/all-MiniLM-L6-v2",
            "intfloat/e5-base-v2",
        ]
    )
    crossencoder_model: str = "cross-encoder/ms-marco-MiniLM-L-6-v2"
    llm_model: str = "llama3.2:1b"
    llm_model_options: list[str] = field(
        default_factory=lambda: [
            "llama3.2:1b",
            "llama3.2:3b",
            "llama3.2",
            "mistral",
            "mistral:7b-instruct-q4_0",
        ]
    )
    ollama_url: str = "http://localhost:11434/api/generate"
    use_hyde: bool = True
    use_reranker: bool = True
    search_top_k: int = 30
    final_top_k: int = 3
    bm25_candidates: int = 150
    rerank_top_k: int = 3
    max_source_chars: int = 900
    llm_num_predict: int = 220
    hyde_num_predict: int = 120
    insert_batch_size: int = 128
    encode_batch_size: int = 32
    index_type: str = "IVF_FLAT"
    metric_type: str = "COSINE"
    nlist: int = 128
    nprobe: int = 16
    max_workers: int = 8
    offline_mode: bool = True
    active_backend: str = "local-api-a"
    external_backends: list[str] = field(
        default_factory=lambda: ["local-api-a", "local-api-b"]
    )
    peer_backends: list[str] = field(default_factory=list)
    scheduler_mode: str = "least_conn"
    rapid_alpha: float = 0.3
    rapid_uncertainty_floor: float = 0.35
    rapid_min_samples: int = 8
    rapid_default_hyde_ms: float = 500.0
    rapid_default_retrieval_ms: float = 1500.0
    rapid_default_generation_ms: float = 30000.0
    adaptive_budget: bool = True
    load_normal_max: float = 0.45
    load_busy_enter: float = 0.60
    load_busy_exit: float = 0.50
    load_saturated_enter: float = 0.80
    load_saturated_exit: float = 0.65
    slo_target_ms: float = 60000.0
    scheduler_backends: dict[str, str] = field(
        default_factory=lambda: {
            "api-a": "http://api-a:8000",
            "api-b": "http://api-b:8000",
        }
    )


def configure_offline_environment(config: RuntimeConfig) -> None:
    cache_dir = PROJECT_ROOT / "model_cache"
    os.environ["HF_HOME"] = str(cache_dir)
    os.environ["HF_HUB_CACHE"] = str(cache_dir / "hub")
    os.environ["DO_NOT_TRACK"] = "1"
    if config.offline_mode:
        os.environ["HF_HUB_OFFLINE"] = "1"
        os.environ["TRANSFORMERS_OFFLINE"] = "1"
        os.environ["HF_DATASETS_OFFLINE"] = "1"


def _read_simple_yaml(path: Path) -> dict[str, Any]:
    data: dict[str, Any] = {}
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.split("#", 1)[0].strip()
        if not line or ":" not in line:
            continue
        key, value = line.split(":", 1)
        value = value.strip()
        if value.lower() in {"true", "false"}:
            parsed: Any = value.lower() == "true"
        elif value.lower() in {"none", "null"}:
            parsed = None
        elif (value.startswith("[") and value.endswith("]")) or (
            value.startswith("{") and value.endswith("}")
        ):
            parsed = json.loads(value.replace("'", '"'))
        else:
            try:
                parsed = int(value)
            except ValueError:
                try:
                    parsed = float(value)
                except ValueError:
                    parsed = value.strip('"').strip("'")
        data[key.strip()] = parsed
    return data


def load_config(path: str | Path | None = None) -> RuntimeConfig:
    config_path = Path(path) if path else PROJECT_ROOT / "config" / "settings.yaml"
    config = RuntimeConfig()
    if config_path.is_file():
        values = _read_simple_yaml(config_path)
        known = {field.name for field in config.__dataclass_fields__.values()}
        config = RuntimeConfig(**{**asdict(config), **{k: v for k, v in values.items() if k in known}})
    config = _apply_environment_overrides(config)
    configure_offline_environment(config)
    return config


def _parse_env_value(raw: str, current: Any) -> Any:
    if isinstance(current, bool):
        return raw.lower() in {"1", "true", "yes", "on"}
    if isinstance(current, int):
        return int(raw)
    if isinstance(current, float):
        return float(raw)
    if isinstance(current, list):
        return json.loads(raw)
    if raw.lower() in {"none", "null"}:
        return None
    return raw


def _apply_environment_overrides(config: RuntimeConfig) -> RuntimeConfig:
    for key in asdict(config):
        env_key = f"MWQ_{key.upper()}"
        if env_key in os.environ:
            setattr(
                config,
                key,
                _parse_env_value(os.environ[env_key], getattr(config, key)),
            )
    return config


def save_config(config: RuntimeConfig, path: str | Path | None = None) -> None:
    config_path = Path(path) if path else PROJECT_ROOT / "config" / "settings.yaml"
    skip = {"peer_backends"}
    lines = []
    for key, value in asdict(config).items():
        if key in skip:
            continue
        lines.append(f"{key}: {json.dumps(value)}")
    config_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
