# Notebook Role

`milvus_rag_pipeline.ipynb` is kept as benchmark evidence and exploration
history. The final project code now lives in `src/milvus_webq`.

Use notebooks for:

- explaining the experiment
- plotting benchmark results
- comparing retrieval variants

Use scripts/API for:

- ingestion
- user questions
- admin runtime changes
- stress tests
