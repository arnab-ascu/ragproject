from __future__ import annotations

import argparse

from milvus_webq.config import load_config
from milvus_webq.service import RAGService


def main() -> None:
    parser = argparse.ArgumentParser(description="User interface: ask a question and get sourced answer.")
    parser.add_argument("query", nargs="*", help="Question to ask")
    parser.add_argument("--trace", action="store_true", help="Show routing and timing trace")
    args = parser.parse_args()

    query = " ".join(args.query).strip() or input("Question: ").strip()
    service = RAGService(load_config())
    response = service.answer(query, include_trace=args.trace)
    print(response["answer"])
    print("\nSources:")
    for source in response["sources"]:
        print(f"- {source['title']} ({source['doc_id']})")
    if args.trace:
        print("\nTrace:")
        print(response["trace"])


if __name__ == "__main__":
    main()
