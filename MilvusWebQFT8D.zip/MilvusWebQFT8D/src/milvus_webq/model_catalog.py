"""Installed-Ollama model discovery with a short, failure-tolerant cache."""

from __future__ import annotations

import time
from dataclasses import dataclass

import requests


@dataclass
class ModelCatalog:
    tags_url: str
    ttl_seconds: float = 30.0
    _models: list[str] | None = None
    _updated_at: float = 0.0
    _error: str | None = None

    def refresh(self, force: bool = False) -> tuple[list[str] | None, str | None]:
        now = time.monotonic()
        if not force and self._models is not None and now - self._updated_at < self.ttl_seconds:
            return self._models, self._error
        try:
            response = requests.get(self.tags_url, timeout=5)
            response.raise_for_status()
            models = sorted(
                item["name"]
                for item in response.json().get("models", [])
                if isinstance(item, dict) and item.get("name")
            )
            self._models, self._error, self._updated_at = models, None, now
        except (requests.RequestException, ValueError) as exc:
            self._models, self._error, self._updated_at = None, str(exc), now
        return self._models, self._error

    def validate(self, model: str | None) -> tuple[bool, str | None]:
        if not model:
            return True, None
        installed, error = self.refresh()
        if installed is None:
            # Preserve offline/development availability while making uncertainty visible.
            return True, error
        if model in installed:
            return True, None
        return False, f"Model '{model}' is not installed. Available models: {', '.join(installed) or 'none'}"
