from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from milvus_webq.config import load_config
from milvus_webq.service import RAGService


def main() -> None:
    parser = argparse.ArgumentParser(description="Ask one query through the full RAG pipeline.")
    parser.add_argument("query", nargs="+")
    parser.add_argument("--trace", action="store_true")
    args = parser.parse_args()

    service = RAGService(load_config())
    response = service.answer(" ".join(args.query), include_trace=args.trace)
    print(json.dumps(response, indent=2))


if __name__ == "__main__":
    main()
